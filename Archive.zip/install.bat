@echo off
title USSU Algorithm Analyzer v4.0 - Installation
echo.
echo  USSU Algorithm Analyzer v4.0 Ultra Pro Max
echo  Installing dependencies...
echo.

:: Check for Python
python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python not found. Please install Python 3.10+ from python.org
    pause
    exit /b 1
)

:: Create venv
if not exist "venv" (
    echo [*] Creating virtual environment...
    python -m venv venv
)

:: Install dependencies
echo [*] Installing dependencies...
venv\Scripts\pip install --upgrade pip
venv\Scripts\pip install -r requirements.txt

echo.
echo  ===========================================
echo  Installation Complete!
echo  ===========================================
echo.
echo  To start Streamlit UI:   start.bat
echo  To start Terminal CLI: start_cli.bat
echo.
pause

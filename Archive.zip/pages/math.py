"""
USSU Algorithm Analyzer v4.0 - Mathematical Tools Page
Number theory, matrix operations, combinatorics, and complexity utilities.
"""
import streamlit as st
import numpy as np
from utils.ui import page_header, algo_card, section_divider, metric_row, theory_box
from algorithms.math_tools import MathTools

page_header("MATHEMATICAL TOOLS", "Number theory, combinatorics, and matrix operations for algorithm analysis")

math_tools = MathTools()

tabs = st.tabs(["🔢 Factorial & Fibonacci", "🔗 GCD & Extended GCD", "🔢 Primes & Sieve", "📐 Matrix & Power", "🗼 Tower of Hanoi", "🔄 Permutations"])

with tabs[0]:
    st.subheader("Factorial")
    n_fact = st.number_input("n", min_value=0, max_value=100, value=10, key="fact_n")
    if st.button("▶️ Compute Factorial", use_container_width=True):
        with st.spinner("Computing..."):
            result = math_tools.factorial(n_fact)
        st.success(f"{n_fact}! = {result['result']}")
        metric_row({
            "Time (ms)": f"{result.get('execution_time_ms', 0):.4f}",
            "Iterations": result['iterations'],
        })

    st.markdown("---")
    st.subheader("Fibonacci Sequence")
    n_fib = st.number_input("n", min_value=0, max_value=50, value=20, key="fib_n")
    method = st.selectbox("Method", ["iterative", "memoization", "recursive"])

    if st.button("▶️ Generate Fibonacci", use_container_width=True):
        with st.spinner("Generating..."):
            result = math_tools.fibonacci(n_fib, method)
        st.success(f"Generated {len(result['sequence'])} numbers")
        if method == "recursive":
            st.warning(f"Recursive method made {result['recursions']} recursive calls! O(2ⁿ) complexity.")
        st.write("Sequence:", result['sequence'])
        metric_row({
            "Time (ms)": f"{result.get('execution_time_ms', 0):.4f}",
            "Recursions": result.get('recursions', 0),
        })

        # Plot
        import matplotlib.pyplot as plt
        fig, ax = plt.subplots(figsize=(10, 4), facecolor='#0f172a')
        ax.set_facecolor('#0f172a')
        seq = result['sequence']
        ax.plot(range(len(seq)), seq, marker='o', color='#06b6d4', linewidth=2, markersize=6)
        ax.set_title(f"Fibonacci Sequence ({method})", color='#22d3ee', fontsize=14, fontweight='bold')
        ax.set_xlabel("Index", color='#94a3b8')
        ax.set_ylabel("Value", color='#94a3b8')
        ax.tick_params(colors='#94a3b8')
        for spine in ax.spines.values():
            spine.set_color('#334155')
        ax.grid(color='#334155', linestyle='--', alpha=0.5)
        plt.tight_layout()
        st.pyplot(fig)

with tabs[1]:
    st.subheader("Euclidean GCD")
    c1, c2 = st.columns(2)
    with c1:
        a = st.number_input("a", min_value=1, value=48, key="gcd_a")
    with c2:
        b = st.number_input("b", min_value=1, value=18, key="gcd_b")

    if st.button("▶️ Compute GCD", use_container_width=True):
        with st.spinner("Computing..."):
            result = math_tools.gcd(a, b)
        st.success(f"GCD({a}, {b}) = {result['gcd']} in {result['steps']} steps")
        metric_row({
            "Time (ms)": f"{result.get('execution_time_ms', 0):.4f}",
            "Iterations": result['iterations'],
        })

    st.markdown("---")
    st.subheader("Extended GCD (Bézout Coefficients)")
    c1, c2 = st.columns(2)
    with c1:
        a2 = st.number_input("a", min_value=1, value=30, key="egcd_a")
    with c2:
        b2 = st.number_input("b", min_value=1, value=12, key="egcd_b")

    if st.button("▶️ Compute Extended GCD", use_container_width=True):
        with st.spinner("Computing..."):
            result = math_tools.extended_gcd(a2, b2)
        st.success(f"GCD({a2}, {b2}) = {result['gcd']} = {result['x']}×{a2} + {result['y']}×{b2}")
        metric_row({
            "Time (ms)": f"{result.get('execution_time_ms', 0):.4f}",
            "Iterations": result['iterations'],
        })

with tabs[2]:
    st.subheader("Primality Test")
    n_prime = st.number_input("n", min_value=1, value=97, key="prime_n")
    if st.button("▶️ Test Primality", use_container_width=True):
        with st.spinner("Testing..."):
            result = math_tools.is_prime(n_prime)
        status = "PRIME" if result['is_prime'] else "NOT PRIME"
        color = "#10b981" if result['is_prime'] else "#ef4444"
        st.markdown(f"<p style='color:{color}; font-size:24px; font-weight:700;'>{n_prime} is {status}</p>", unsafe_allow_html=True)
        st.write(f"Divisibility checks performed: {result['checks']}")
        metric_row({
            "Time (ms)": f"{result.get('execution_time_ms', 0):.4f}",
            "Iterations": result['iterations'],
            "Comparisons": result['comparisons'],
        })

    st.markdown("---")
    st.subheader("Sieve of Eratosthenes")
    n_sieve = st.number_input("Find primes up to", min_value=2, value=100, key="sieve_n")
    if st.button("▶️ Generate Primes", use_container_width=True):
        with st.spinner("Sieving..."):
            result = math_tools.sieve_eratosthenes(n_sieve)
        st.success(f"Found {result['count']} primes up to {n_sieve}")
        st.write("Primes:", result['primes'])
        metric_row({
            "Time (ms)": f"{result.get('execution_time_ms', 0):.4f}",
            "Iterations": result['iterations'],
            "Comparisons": result['comparisons'],
        })

with tabs[3]:
    st.subheader("Fast Exponentiation")
    c1, c2 = st.columns(2)
    with c1:
        base = st.number_input("Base", value=2.0, key="pow_base")
    with c2:
        exp = st.number_input("Exponent", min_value=0, value=20, key="pow_exp")

    if st.button("▶️ Compute Power", use_container_width=True):
        with st.spinner("Computing..."):
            result = math_tools.fast_exponentiation(base, exp)
        st.success(f"{base}^{exp} = {result['result']}")
        metric_row({
            "Time (ms)": f"{result.get('execution_time_ms', 0):.4f}",
            "Iterations": result['iterations'],
        })

    st.markdown("---")
    st.subheader("Modular Exponentiation")
    c1, c2, c3 = st.columns(3)
    with c1:
        m_base = st.number_input("Base", value=3, key="mod_base")
    with c2:
        m_exp = st.number_input("Exp", min_value=0, value=100, key="mod_exp")
    with c3:
        mod = st.number_input("Mod", min_value=2, value=7, key="mod_mod")

    if st.button("▶️ Compute Modular Power", use_container_width=True):
        with st.spinner("Computing..."):
            result = math_tools.modular_exponentiation(m_base, m_exp, mod)
        st.success(f"{m_base}^{m_exp} mod {mod} = {result['result']}")
        metric_row({
            "Time (ms)": f"{result.get('execution_time_ms', 0):.4f}",
            "Iterations": result['iterations'],
        })

    st.markdown("---")
    st.subheader("Matrix Multiplication")
    st.markdown("Enter two N×N matrices (rows separated by newlines, elements by spaces)")

    c1, c2 = st.columns(2)
    with c1:
        mat_a = st.text_area("Matrix A", "1 2\n3 4", height=100)
    with c2:
        mat_b = st.text_area("Matrix B", "5 6\n7 8", height=100)

    try:
        A = [list(map(float, row.split())) for row in mat_a.strip().split('\n')]
        B = [list(map(float, row.split())) for row in mat_b.strip().split('\n')]

        if st.button("▶️ Multiply Matrices", use_container_width=True):
            with st.spinner("Multiplying..."):
                result = math_tools.matrix_multiply(A, B)
            st.success("Multiplication Complete")
            st.write("Result:")
            st.dataframe(result['result'], use_container_width=True)
            metric_row({
                "Time (ms)": f"{result.get('execution_time_ms', 0):.4f}",
                "Iterations": result['iterations'],
                "Accesses": result['accesses'],
            })
    except Exception as e:
        st.error(f"Invalid matrix input: {e}")

with tabs[4]:
    st.subheader("Tower of Hanoi")
    n_disks = st.slider("Disks", 1, 10, 4)
    if st.button("▶️ Solve Tower of Hanoi", use_container_width=True):
        with st.spinner("Solving..."):
            result = math_tools.tower_of_hanoi(n_disks)
        st.success(f"Total moves: {result['total_moves']} (2^{n_disks} - 1 = {2**n_disks - 1})")
        st.write("Moves:")
        for move in result['moves']:
            st.code(move)
        metric_row({
            "Time (ms)": f"{result.get('execution_time_ms', 0):.4f}",
            "Recursions": result['recursions'],
        })

with tabs[5]:
    st.subheader("Generate Permutations")
    items = st.text_input("Items (space separated)", "A B C D")
    arr = items.split()
    if st.button("▶️ Generate All Permutations", use_container_width=True):
        with st.spinner("Generating..."):
            result = math_tools.generate_permutations(arr)
        st.success(f"Generated {result['count']} permutations")
        st.write("First 20:")
        for perm in result['permutations'][:20]:
            st.code(' '.join(map(str, perm)))
        metric_row({
            "Time (ms)": f"{result.get('execution_time_ms', 0):.4f}",
            "Recursions": result['recursions'],
            "Iterations": result['iterations'],
        })

theory_box("Mathematical Foundations", 
    "<strong>Modular arithmetic</strong> is the backbone of cryptography (RSA, Diffie-Hellman).<br>"
    "<strong>Matrix multiplication</strong> complexity: naive O(n³), Strassen O(n^2.807), current best ~O(n^2.373).<br>"
    "<strong>Prime testing</strong> moved from O(√n) trial division to O(log³ n) probabilistic (Miller-Rabin) and deterministic (AKS).",
    "info")

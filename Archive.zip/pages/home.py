"""
USSU Algorithm Analyzer v4.0 - Home Page
Cyberpunk dashboard with feature overview and quick stats.
"""
import streamlit as st
from utils.ui import page_header, algo_card, section_divider, theory_box

page_header("USSU ALGORITHM ANALYZER", "The most advanced algorithm analysis suite ever built — now in Streamlit Cyberpunk Edition")

# Hero section
st.markdown("""
<div style="background: linear-gradient(135deg, rgba(6,182,212,0.1) 0%, rgba(139,92,246,0.1) 100%); 
            border: 1px solid #334155; border-radius: 16px; padding: 24px; margin-bottom: 24px;">
    <p style="color: #94a3b8; font-size: 16px; line-height: 1.7; margin: 0;">
        Designed for <strong style="color:#22d3ee;">students, researchers, CTF players, and engineers</strong> who refuse to use boring tools.
        Transform dry algorithm theory into an immersive, visual, and metrics-driven experience.
        Every algorithm is profiled with <strong style="color:#10b981;">execution time</strong>, 
        <strong style="color:#8b5cf6;">memory usage</strong>, and <strong style="color:#f59e0b;">operation counters</strong>.
    </p>
</div>
""", unsafe_allow_html=True)

# Quick stats
st.markdown("""
<div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px; margin-bottom: 24px;">
    <div style="background: rgba(30,41,59,0.9); border: 1px solid #06b6d4; border-radius: 12px; padding: 16px; text-align: center;">
        <p style="color: #06b6d4; font-size: 32px; font-weight: 700; margin: 0; font-family: 'Orbitron', sans-serif;">50+</p>
        <p style="color: #94a3b8; font-size: 12px; margin: 4px 0 0 0;">ALGORITHMS</p>
    </div>
    <div style="background: rgba(30,41,59,0.9); border: 1px solid #8b5cf6; border-radius: 12px; padding: 16px; text-align: center;">
        <p style="color: #8b5cf6; font-size: 32px; font-weight: 700; margin: 0; font-family: 'Orbitron', sans-serif;">12</p>
        <p style="color: #94a3b8; font-size: 12px; margin: 4px 0 0 0;">CATEGORIES</p>
    </div>
    <div style="background: rgba(30,41,59,0.9); border: 1px solid #10b981; border-radius: 12px; padding: 16px; text-align: center;">
        <p style="color: #10b981; font-size: 32px; font-weight: 700; margin: 0; font-family: 'Orbitron', sans-serif;">∞</p>
        <p style="color: #94a3b8; font-size: 12px; margin: 4px 0 0 0;">BENCHMARKS</p>
    </div>
    <div style="background: rgba(30,41,59,0.9); border: 1px solid #f59e0b; border-radius: 12px; padding: 16px; text-align: center;">
        <p style="color: #f59e0b; font-size: 32px; font-weight: 700; margin: 0; font-family: 'Orbitron', sans-serif;">v4.0</p>
        <p style="color: #94a3b8; font-size: 12px; margin: 4px 0 0 0;">ULTRA PRO MAX</p>
    </div>
</div>
""", unsafe_allow_html=True)

section_divider("FEATURE MATRIX")

cols = st.columns(3)
features = [
    ("🕸️ Graph Theory", "BFS, DFS, Dijkstra, Bellman-Ford, Floyd-Warshall, A*, Prim, Kruskal, SCC, Topological Sort, Longest Path DAG"),
    ("🔍 Searching", "Linear, Binary, Jump, Interpolation, Exponential, Ternary, Fibonacci — all with complexity tracking"),
    ("📊 Sorting", "Bubble, Selection, Insertion, Merge, Quick, Heap, Shell, Cocktail, Comb, Counting, Radix, Bucket, Timsort"),
    ("🧩 Dynamic Programming", "Knapsack (0/1 & Unbounded), LCS, Edit Distance, Matrix Chain, Coin Change, LIS"),
    ("💎 Greedy", "Activity Selection, Fractional Knapsack, Huffman Coding, Job Sequencing, Minimum Coins"),
    ("🌲 Backtracking", "N-Queens, Sudoku, Subset Sum, Graph Coloring, Hamiltonian Cycle"),
    ("📚 ADA Theory", "Master Theorem, Amortized Analysis, NP-Completeness, Paradigm Comparison, Asymptotic Notation"),
    ("🔢 Math Tools", "Factorial, Fibonacci, GCD, Extended GCD, Primes, Sieve, Matrix Multiply, Tower of Hanoi, Permutations"),
    ("⏱️ Benchmarks", "Cross-size performance suites with cyberpunk visualizations and statistical profiling"),
]

for i, (title, desc) in enumerate(features):
    with cols[i % 3]:
        st.markdown(f"""
        <div style="background: rgba(30,41,59,0.8); border: 1px solid #334155; border-radius: 10px; padding: 14px; margin-bottom: 12px;">
            <h4 style="color: #22d3ee; font-size: 15px; margin: 0 0 6px 0; font-family: 'Orbitron', sans-serif;">{title}</h4>
            <p style="color: #94a3b8; font-size: 12px; margin: 0; line-height: 1.5;">{desc}</p>
        </div>
        """, unsafe_allow_html=True)

section_divider("DESIGN PHILOSOPHY")

theory_box("50-30-20 Futuristic Color Rule", 
    "<strong style='color:#1e293b'>50% Deep Slate</strong> — Primary backgrounds and panels.<br>"
    "<strong style='color:#374151'>30% Charcoal Gray</strong> — Secondary elements and borders.<br>"
    "<strong style='color:#06b6d4'>20% Vibrant Cyan</strong> — Accents, highlights, and interactive elements.",
    "info")

theory_box("Performance First", 
    "Every algorithm execution is wrapped with <code>tracemalloc</code> and <code>time.perf_counter()</code> for millisecond-accurate profiling. "
    "Operation counters track comparisons, swaps, accesses, and recursions in real-time.",
    "success")

theory_box("Kali Linux & Windows 11 Ready", 
    "Built with cross-platform compatibility. Includes <code>start.sh</code> and <code>install.sh</code> scripts "
    "that handle venv activation properly on both bash and PowerShell environments.",
    "warning")

st.markdown("""
<div style="text-align: center; margin-top: 40px; padding: 20px; border-top: 1px solid #334155;">
    <p style="color: #64748b; font-size: 13px;">
        Built with ❤️ by <strong style="color:#06b6d4;">Ussu</strong> 
        | <a href="https://github.com/issu321" target="_blank" style="color:#06b6d4; text-decoration:none;">github.com/issu321</a>
        | MIT License
    </p>
</div>
""", unsafe_allow_html=True)

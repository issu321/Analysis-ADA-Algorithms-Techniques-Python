"""
USSU Algorithm Analyzer v4.0 - Graph Algorithms Page
Interactive graph creation, visualization, and algorithm execution.
"""
import streamlit as st
import numpy as np
import pandas as pd
from utils.core import Graph
from utils.ui import page_header, algo_card, section_divider, metric_row, result_box, theory_box
from utils.viz import plot_graph_cyber
from algorithms.graph import GraphAlgorithms

page_header("GRAPH ALGORITHMS", "Create, visualize, and analyze graphs with BFS, DFS, shortest paths, MST, and more")

# Session state for graph
if 'current_graph' not in st.session_state:
    st.session_state.current_graph = None
if 'graph_history' not in st.session_state:
    st.session_state.graph_history = []

# Sidebar controls
with st.sidebar:
    st.markdown("<h3 style='color:#22d3ee; font-family:Orbitron;'>⚙️ Graph Controls</h3>", unsafe_allow_html=True)

    graph_mode = st.radio("Graph Mode", ["Random", "Custom", "Load from String"], index=0)

    if graph_mode == "Random":
        n_vertices = st.slider("Vertices", 3, 50, 8)
        edge_prob = st.slider("Edge Probability", 0.0, 1.0, 0.3)
        directed = st.toggle("Directed", False)
        weighted = st.toggle("Weighted", True)
        if st.button("🎲 Generate Random Graph", use_container_width=True):
            st.session_state.current_graph = Graph.from_random(n_vertices, edge_prob, directed, weighted)
            st.session_state.graph_history.append("Random graph generated")
            st.rerun()

    elif graph_mode == "Custom":
        directed = st.toggle("Directed", False)
        weighted = st.toggle("Weighted", True)
        edges_input = st.text_area("Edges (u v [weight] per line)", "0 1 5\n1 2 3\n2 0 2\n0 3 1", height=120)
        if st.button("🔨 Build Custom Graph", use_container_width=True):
            st.session_state.current_graph = Graph.from_edges(edges_input, directed, weighted)
            st.session_state.graph_history.append("Custom graph built")
            st.rerun()

    elif graph_mode == "Load from String":
        preset = st.selectbox("Preset", ["Triangle", "Square", "Star", "Complete K5", "Path P6", "Custom"])
        if preset == "Triangle":
            edges_str = "0 1 1\n1 2 1\n2 0 1"
        elif preset == "Square":
            edges_str = "0 1 1\n1 2 1\n2 3 1\n3 0 1"
        elif preset == "Star":
            edges_str = "0 1 1\n0 2 1\n0 3 1\n0 4 1"
        elif preset == "Complete K5":
            edges_str = "\n".join([f"{i} {j} 1" for i in range(5) for j in range(i+1, 5)])
        elif preset == "Path P6":
            edges_str = "\n".join([f"{i} {i+1} 1" for i in range(5)])
        else:
            edges_str = st.text_area("Edges", "0 1 5\n1 2 3", height=100)
        if st.button("📥 Load Preset", use_container_width=True):
            st.session_state.current_graph = Graph.from_edges(edges_str, False, True)
            st.session_state.graph_history.append(f"Preset {preset} loaded")
            st.rerun()

# Main content
if st.session_state.current_graph is None:
    st.info("👈 Use the sidebar to create or load a graph first.")
    theory_box("Graph Representation", 
        "We support both <strong>Adjacency List</strong> (sparse graphs) and <strong>Adjacency Matrix</strong> (dense graphs). "
        "Visualizations use NetworkX with cyberpunk styling: cyan nodes, violet edges, and white labels.",
        "info")
else:
    g = st.session_state.current_graph

    # Graph info cards
    col1, col2, col3, col4 = st.columns(4)
    with col1:
        st.metric("Vertices", len(g.vertices))
    with col2:
        st.metric("Edges", g.edge_count)
    with col3:
        st.metric("Type", "Directed" if g.directed else "Undirected")
    with col4:
        density = g.edge_count / (len(g.vertices) * (len(g.vertices)-1)) if len(g.vertices) > 1 else 0
        st.metric("Density", f"{density:.3f}")

    # Visualization
    section_divider("GRAPH VISUALIZATION")
    fig = plot_graph_cyber(g, title=f"{'Directed' if g.directed else 'Undirected'} Graph | {len(g.vertices)}V {g.edge_count}E")
    st.pyplot(fig)

    # Algorithm selection
    section_divider("RUN ALGORITHM")

    algo_tabs = st.tabs([
        "🔎 Traversal", "📏 Shortest Path", "🌳 MST", "📐 DAG Analysis", "🔗 SCC", "🧭 A* Search"
    ])

    analyzer = GraphAlgorithms()

    with algo_tabs[0]:
        st.subheader("BFS & DFS Traversal")
        col_a, col_b = st.columns(2)
        with col_a:
            start_node = st.number_input("Start Node", min_value=0, max_value=max(g.vertices), value=min(g.vertices))
        with col_b:
            target_node = st.number_input("Target Node (optional)", min_value=-1, max_value=max(g.vertices), value=-1)
        target_node = None if target_node == -1 else target_node

        col1, col2 = st.columns(2)
        with col1:
            if st.button("▶️ Run BFS", use_container_width=True):
                with st.spinner("Running BFS..."):
                    result = analyzer.bfs(g, start_node, target_node)
                st.success(f"BFS Complete — Visited {len(result.get('visited', set()))} nodes")
                metric_row({
                    "Time (ms)": f"{result.get('execution_time_ms', 0):.4f}",
                    "Memory (KB)": f"{result.get('memory_used_kb', 0):.2f}",
                    "Iterations": result.get('iterations', 0),
                    "Path Length": len(result.get('path', [])) if result.get('path') else 0,
                })
                if result.get('path'):
                    st.write("**Path:**", " → ".join(map(str, result['path'])))
                st.write("**Traversal:**", " → ".join(map(str, result.get('traversal', []))))

        with col2:
            if st.button("▶️ Run DFS", use_container_width=True):
                with st.spinner("Running DFS..."):
                    result = analyzer.dfs_iterative(g, start_node, target_node)
                st.success(f"DFS Complete — Visited {len(result.get('visited', set()))} nodes")
                metric_row({
                    "Time (ms)": f"{result.get('execution_time_ms', 0):.4f}",
                    "Memory (KB)": f"{result.get('memory_used_kb', 0):.2f}",
                    "Iterations": result.get('iterations', 0),
                    "Path Length": len(result.get('path', [])) if result.get('path') else 0,
                })
                st.write("**Traversal:**", " → ".join(map(str, result.get('traversal', []))))

    with algo_tabs[1]:
        st.subheader("Shortest Path Algorithms")
        start_sp = st.number_input("Start", min_value=0, max_value=max(g.vertices), value=min(g.vertices), key="sp_start")
        target_sp = st.number_input("Target", min_value=0, max_value=max(g.vertices), value=max(g.vertices), key="sp_target")

        col1, col2, col3 = st.columns(3)
        with col1:
            if st.button("▶️ Dijkstra", use_container_width=True):
                with st.spinner("Running Dijkstra..."):
                    result = analyzer.dijkstra(g, start_sp, target_sp)
                if result.get('error'):
                    st.error(result['error'])
                else:
                    st.success(f"Distance: {result['distances'].get(target_sp, '∞')}")
                    if result.get('path'):
                        fig_path = plot_graph_cyber(g, highlight_path=result['path'], 
                                                    title=f"Dijkstra Path | Cost: {result['distances'].get(target_sp, 0):.2f}")
                        st.pyplot(fig_path)
        with col2:
            if st.button("▶️ Bellman-Ford", use_container_width=True):
                with st.spinner("Running Bellman-Ford..."):
                    result = analyzer.bellman_ford(g, start_sp)
                if result.get('error'):
                    st.error(result['error'])
                else:
                    st.success("Bellman-Ford Complete")
                    st.json({k: f"{v:.2f}" if v != float('inf') else "∞" for k, v in result['distances'].items()})
        with col3:
            if st.button("▶️ Floyd-Warshall", use_container_width=True):
                with st.spinner("Running Floyd-Warshall..."):
                    result = analyzer.floyd_warshall(g)
                st.success("All-Pairs Shortest Path Complete")
                # Show a sample of the matrix
                vertices = sorted(list(g.vertices))[:6]
                sample_matrix = [[f"{result['distances'][i][j]:.1f}" if result['distances'][i][j] != float('inf') else "∞" 
                                  for j in vertices] for i in vertices]
                st.write("Distance Matrix (sample):")
                df_fw = pd.DataFrame(sample_matrix, 
                                     index=[f"From {v}" for v in vertices],
                                     columns=[f"To {v}" for v in vertices])
                st.dataframe(df_fw, use_container_width=True)

    with algo_tabs[2]:
        st.subheader("Minimum Spanning Tree")
        if g.directed:
            st.warning("MST requires an undirected graph. Please regenerate without 'Directed' enabled.")
        else:
            col1, col2 = st.columns(2)
            with col1:
                if st.button("▶️ Prim's Algorithm", use_container_width=True):
                    with st.spinner("Running Prim..."):
                        result = analyzer.prim_mst(g)
                    if result.get('error'):
                        st.error(result['error'])
                    else:
                        st.success(f"MST Weight: {result['total_weight']:.2f}")
                        st.write("MST Edges:", result['mst_edges'])
            with col2:
                if st.button("▶️ Kruskal's Algorithm", use_container_width=True):
                    with st.spinner("Running Kruskal..."):
                        result = analyzer.kruskal_mst(g)
                    if result.get('error'):
                        st.error(result['error'])
                    else:
                        st.success(f"MST Weight: {result['total_weight']:.2f}")
                        st.write("MST Edges:", result['mst_edges'])

    with algo_tabs[3]:
        st.subheader("DAG Analysis")
        start_dag = st.number_input("Start", min_value=0, max_value=max(g.vertices), value=min(g.vertices), key="dag_start")
        if st.button("▶️ Longest Path (DAG)", use_container_width=True):
            with st.spinner("Computing..."):
                result = analyzer.longest_path_dag(g, start_dag)
            st.success("Longest Path Complete")
            st.json({k: f"{v:.2f}" if v != float('-inf') else "-∞" for k, v in result['distances'].items()})
        if st.button("▶️ Topological Sort", use_container_width=True):
            with st.spinner("Sorting..."):
                result = analyzer.topological_sort(g)
            st.success(f"Topological Order: {' → '.join(map(str, result['topological_order']))}")
            st.write(f"Valid DAG: {result['valid']}")

    with algo_tabs[4]:
        st.subheader("Strongly Connected Components")
        if not g.directed:
            st.warning("SCC requires a directed graph.")
        else:
            if st.button("▶️ Kosaraju SCC", use_container_width=True):
                with st.spinner("Finding SCCs..."):
                    result = analyzer.kosaraju_scc(g)
                st.success(f"Found {result['count']} SCCs")
                for i, scc in enumerate(result['sccs']):
                    st.write(f"SCC {i+1}: {scc}")

    with algo_tabs[5]:
        st.subheader("A* Search")
        start_astar = st.number_input("Start", min_value=0, max_value=max(g.vertices), value=min(g.vertices), key="astar_start")
        target_astar = st.number_input("Target", min_value=0, max_value=max(g.vertices), value=max(g.vertices), key="astar_target")
        if st.button("▶️ Run A*", use_container_width=True):
            with st.spinner("Running A*..."):
                result = analyzer.a_star(g, start_astar, target_astar)
            if result['found']:
                st.success(f"Path found! Cost: {result['cost']:.2f}")
                fig_astar = plot_graph_cyber(g, highlight_path=result['path'], title="A* Search Path")
                st.pyplot(fig_astar)
            else:
                st.error("No path found")

"""
USSU Algorithm Analyzer v4.0 - Sorting Algorithms Page
Interactive sorting with step visualization, metrics, and benchmark comparison.
"""
import streamlit as st
import random
from utils.ui import page_header, algo_card, section_divider, metric_row, theory_box
from utils.viz import plot_sorting_step, plot_benchmark_bar
from algorithms.sort import SortingAlgorithms

page_header("SORTING ALGORITHMS", "Bubble, Selection, Insertion, Merge, Quick, Heap, Shell, Cocktail, Comb, Counting, Radix, Bucket, Timsort")

sorter = SortingAlgorithms(capture_steps=False)

# Input
st.html("<h3 style='color:#22d3ee; font-family:Orbitron; margin-top:0;'>🔧 Input Configuration</h3>")
col1, col2 = st.columns([2, 1])
with col1:
    input_mode = st.radio("Array Source", ["Manual Entry", "Random Generate"], horizontal=True, key="sort_input")
    if input_mode == "Manual Entry":
        arr_input = st.text_input("Numbers (space separated)", "64 34 25 12 22 11 90 88 42 77")
        arr = list(map(int, arr_input.split()))
    else:
        size = st.slider("Array Size", 5, 5000, 50, key="sort_size")
        max_val = st.slider("Max Value", 10, 10000, 100, key="sort_max")
        arr = [random.randint(0, max_val) for _ in range(size)]
with col2:
    st.metric("Elements", len(arr))
    st.metric("Range", f"{min(arr)} - {max(arr)}" if arr else "N/A")
    enable_viz = st.toggle("Enable Step Viz", False, help="Capture sorting steps for visualization (slower)")

# Algorithm cards
section_divider("RUN ALGORITHMS")

sort_algos = [
    ("Bubble Sort", "O(n²)", "O(1)", "Yes", sorter.bubble_sort),
    ("Selection Sort", "O(n²)", "O(1)", "No", sorter.selection_sort),
    ("Insertion Sort", "O(n²)", "O(1)", "Yes", sorter.insertion_sort),
    ("Merge Sort", "O(n log n)", "O(n)", "Yes", sorter.merge_sort),
    ("Quick Sort", "O(n log n)", "O(log n)", "No", sorter.quick_sort),
    ("Heap Sort", "O(n log n)", "O(1)", "No", sorter.heap_sort),
    ("Shell Sort", "O(n log² n)", "O(1)", "No", sorter.shell_sort),
    ("Cocktail Shaker", "O(n²)", "O(1)", "Yes", sorter.cocktail_shaker_sort),
    ("Comb Sort", "O(n²/2^p)", "O(1)", "No", sorter.comb_sort),
    ("Counting Sort", "O(n+k)", "O(k)", "Yes", sorter.counting_sort),
    ("Radix Sort", "O(d(n+k))", "O(n+k)", "Yes", sorter.radix_sort),
    ("Bucket Sort", "O(n+k)", "O(n+k)", "Yes", sorter.bucket_sort),
    ("Timsort", "O(n log n)", "O(n)", "Yes", sorter.tim_sort),
]

for i in range(0, len(sort_algos), 3):
    cols = st.columns(3)
    for j in range(3):
        if i + j < len(sort_algos):
            name, time_c, space_c, stable, func = sort_algos[i + j]
            with cols[j]:
                algo_card(name, time_c, space_c, stable, desc="")
                btn_key = f"sort_btn_{i+j}"
                if st.button(f"▶️ Sort", key=btn_key, use_container_width=True):
                    if len(arr) > 2000 and name in ["Bubble Sort", "Selection Sort", "Insertion Sort", "Cocktail Shaker"]:
                        st.warning(f"{name} skipped for large arrays (>2000). Use faster algorithms.")
                    else:
                        with st.spinner(f"Running {name}..."):
                            if enable_viz and name in ["Bubble Sort", "Insertion Sort", "Selection Sort"]:
                                viz_sorter = SortingAlgorithms(capture_steps=True)
                                viz_func = getattr(viz_sorter, func.__name__)
                                result = viz_func(arr)
                            else:
                                result = func(arr)

                        st.success(f"Sorted in {result['execution_time_ms']:.4f}ms")
                        metric_row({
                            "Comparisons": result['comparisons'],
                            "Swaps": result['swaps'],
                            "Accesses": result['accesses'],
                            "Recursions": result['recursions'],
                        })

                        # Show sorted preview
                        sorted_arr = result['sorted']
                        preview = sorted_arr[:20]
                        st.write(f"**Sorted:** {preview}{'...' if len(sorted_arr) > 20 else ''}")

                        # Step visualization for small arrays
                        if enable_viz and result.get('steps') and len(result['steps']) > 0:
                            st.write(f"**Steps captured:** {len(result['steps'])}")
                            step_idx = st.slider("View Step", 0, len(result['steps'])-1, 0, key=f"step_{i+j}")
                            fig = plot_sorting_step(result['steps'][step_idx]['array'], 
                                                    title=result['steps'][step_idx].get('title', 'Sorting'),
                                                    compare=result['steps'][step_idx].get('compare'),
                                                    swap=result['steps'][step_idx].get('swap'),
                                                    sorted_prefix=result['steps'][step_idx].get('sorted_prefix', 0))
                            st.pyplot(fig)

# Benchmark
section_divider("BENCHMARK SUITE")

if st.button("🏁 Compare All Sorting Algorithms", use_container_width=True, key="sort_bench"):
    with st.spinner("Benchmarking..."):
        results = sorter.compare_all(arr)

    st.success("Benchmark Complete!")
    valid = [r for r in results if 'error' not in r and r['time_ms'] != float('inf')]

    # Build complete table HTML in one block
    table_html = ["""
    <table style="width:100%; border-collapse:collapse; font-size:13px;">
        <tr style="background:#1e293b; color:#22d3ee;">
            <th style="padding:10px; text-align:left;">Algorithm</th>
            <th style="padding:10px;">Time (ms)</th>
            <th style="padding:10px;">Time Comp.</th>
            <th style="padding:10px;">Space</th>
            <th style="padding:10px;">Stable</th>
        </tr>
    """]

    for r in results:
        if 'error' in r:
            continue
        time_str = f"{r['time_ms']:.6f}" if r['time_ms'] != float('inf') else "SKIPPED"
        stable_color = "#10b981" if r['stable'] == 'Yes' else "#ef4444"
        table_html.append(f"""
        <tr style="border-bottom:1px solid #334155;">
            <td style="padding:8px; color:#f8fafc;">{r['name']}</td>
            <td style="padding:8px; color:#06b6d4; text-align:center;">{time_str}</td>
            <td style="padding:8px; color:#a78bfa; text-align:center;">{r['complexity']}</td>
            <td style="padding:8px; color:#f59e0b; text-align:center;">{r['space']}</td>
            <td style="padding:8px; color:{stable_color}; text-align:center; font-weight:700;">{r['stable']}</td>
        </tr>
        """)
    table_html.append("</table>")
    st.html("".join(table_html))

    if valid:
        fig = plot_benchmark_bar(valid, title="Sorting Algorithm Speed Comparison")
        st.pyplot(fig)

theory_box("Sorting Stability", 
    "A <strong>stable</strong> sort preserves the relative order of equal elements. Critical when sorting by multiple keys. "
    "<strong>Merge Sort</strong> and <strong>Timsort</strong> are stable; <strong>Quick Sort</strong> and <strong>Heap Sort</strong> are not (without extra work).",
    "info")

theory_box("In-Place Sorting", 
    "<strong>In-place</strong> algorithms use O(1) extra space: Bubble, Selection, Insertion, Heap, Shell, Comb. "
    "<strong>Merge Sort</strong> requires O(n) auxiliary space. <strong>Quick Sort</strong> uses O(log n) stack space on average.",
    "warning")
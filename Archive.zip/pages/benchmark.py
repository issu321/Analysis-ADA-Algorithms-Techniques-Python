"""
USSU Algorithm Analyzer v4.0 - Benchmark Suite Page
Cross-size performance analysis with cyberpunk visualizations.
"""
import streamlit as st
import pandas as pd
from utils.ui import page_header, section_divider, metric_row, theory_box
from utils.viz import plot_benchmark_lines
from algorithms.benchmark import BenchmarkSuite

page_header("BENCHMARK SUITE", "Cross-size performance analysis with statistical profiling")

suite = BenchmarkSuite()

tabs = st.tabs(["🔍 Search Benchmark", "📊 Sort Benchmark", "🕸️ Graph Benchmark", "🧩 DP Benchmark", "📈 Custom Profile"])

with tabs[0]:
    st.subheader("Search Algorithm Scaling")
    sizes = st.multiselect("Input Sizes", [100, 500, 1000, 5000, 10000, 50000], default=[100, 1000, 5000, 10000])
    trials = st.slider("Trials per size", 1, 20, 5)

    if st.button("▶️ Run Search Benchmark", use_container_width=True):
        with st.spinner("Benchmarking search algorithms across sizes..."):
            results = suite.benchmark_search(sizes, trials)

        st.success("Benchmark Complete!")

        # DataFrame
        df_data = []
        for r in results:
            row = {'size': r['size']}
            row.update(r['times'])
            df_data.append(row)
        df = pd.DataFrame(df_data)
        st.dataframe(df.style.highlight_min(subset=df.columns[1:], color='#10b98120'), use_container_width=True)

        # Line plot
        plot_data = {}
        for algo_name in df.columns[1:]:
            plot_data[algo_name] = [{'size': r['size'], 'time_ms': r['times'][algo_name]} for r in results]
        fig = plot_benchmark_lines(plot_data, x_key='size', y_key='time_ms', title="Search Algorithm Scaling")
        st.pyplot(fig)

with tabs[1]:
    st.subheader("Sort Algorithm Scaling")
    sizes = st.multiselect("Input Sizes", [100, 500, 1000, 2000, 5000], default=[100, 500, 1000, 2000], key="sort_sizes")

    if st.button("▶️ Run Sort Benchmark", use_container_width=True):
        with st.spinner("Benchmarking sort algorithms..."):
            results = suite.benchmark_sort(sizes)

        st.success("Benchmark Complete!")
        df_data = []
        for r in results:
            row = {'size': r['size']}
            for algo, time in r['times'].items():
                row[algo] = 'INF' if time == float('inf') else round(time, 4)
            df_data.append(row)
        df = pd.DataFrame(df_data)
        st.dataframe(df, use_container_width=True)

        # Filter out INF for plotting
        plot_data = {}
        for algo_name in [c for c in df.columns if c != 'size']:
            points = []
            for r in results:
                t = r['times'][algo_name]
                if t != float('inf'):
                    points.append({'size': r['size'], 'time_ms': t})
            if points:
                plot_data[algo_name] = points

        if plot_data:
            fig = plot_benchmark_lines(plot_data, x_key='size', y_key='time_ms', title="Sort Algorithm Scaling")
            st.pyplot(fig)

with tabs[2]:
    st.subheader("Graph Algorithm Scaling")
    sizes = st.multiselect("Graph Sizes (vertices)", [10, 20, 50, 100, 200], default=[10, 20, 50, 100])

    if st.button("▶️ Run Graph Benchmark", use_container_width=True):
        with st.spinner("Benchmarking graph algorithms..."):
            results = suite.benchmark_graph(sizes)

        st.success("Benchmark Complete!")
        df = pd.DataFrame(results)
        st.dataframe(df, use_container_width=True)

        plot_data = {
            'Dijkstra': [{'size': r['size'], 'time_ms': r['dijkstra']} for r in results],
            'BFS': [{'size': r['size'], 'time_ms': r['bfs']} for r in results],
            'DFS': [{'size': r['size'], 'time_ms': r['dfs']} for r in results],
        }
        fig = plot_benchmark_lines(plot_data, x_key='size', y_key='time_ms', title="Graph Algorithm Scaling")
        st.pyplot(fig)

with tabs[3]:
    st.subheader("Dynamic Programming Scaling")
    sizes = st.multiselect("Problem Sizes", [5, 10, 15, 20, 25], default=[5, 10, 15, 20])

    if st.button("▶️ Run DP Benchmark", use_container_width=True):
        with st.spinner("Benchmarking DP algorithms..."):
            results = suite.benchmark_dp(sizes)

        st.success("Benchmark Complete!")
        df = pd.DataFrame(results)
        st.dataframe(df, use_container_width=True)

        plot_data = {
            'Knapsack': [{'size': r['size'], 'time_ms': r['knapsack']} for r in results],
            'LCS': [{'size': r['size'], 'time_ms': r['lcs']} for r in results],
        }
        fig = plot_benchmark_lines(plot_data, x_key='size', y_key='time_ms', title="DP Algorithm Scaling")
        st.pyplot(fig)

with tabs[4]:
    st.subheader("Custom Speed Profile")
    st.markdown("Profile any algorithm function with detailed statistics")

    algo_type = st.selectbox("Algorithm", [
        "Linear Search", "Binary Search", "Bubble Sort", "Merge Sort", 
        "Quick Sort", "Dijkstra", "BFS", "Knapsack"
    ])

    size = st.slider("Input Size", 10, 10000, 1000, key="prof_size")
    warmup = st.slider("Warmup Runs", 0, 5, 2)
    trials = st.slider("Measurement Trials", 1, 50, 10)

    if st.button("▶️ Profile Algorithm", use_container_width=True):
        with st.spinner("Profiling..."):
            # Setup based on algorithm type
            if algo_type in ["Linear Search", "Binary Search"]:
                import random
                from algorithms.search import SearchingAlgorithms
                s = SearchingAlgorithms()
                arr = sorted(random.sample(range(size*2), size))
                target = random.choice(arr)
                if algo_type == "Linear Search":
                    func = lambda: s.linear_search(arr, target)
                else:
                    func = lambda: s.binary_search_iterative(arr, target)
            elif algo_type in ["Bubble Sort", "Merge Sort", "Quick Sort"]:
                import random
                from algorithms.sort import SortingAlgorithms
                s = SortingAlgorithms()
                arr = [random.randint(0, size) for _ in range(min(size, 2000))]
                if algo_type == "Bubble Sort":
                    func = lambda: s.bubble_sort(arr)
                elif algo_type == "Merge Sort":
                    func = lambda: s.merge_sort(arr)
                else:
                    func = lambda: s.quick_sort(arr)
            elif algo_type == "Dijkstra":
                from utils.core import Graph
                from algorithms.graph import GraphAlgorithms
                g = Graph.from_random(min(size, 100), 0.2, weighted=True)
                ga = GraphAlgorithms()
                func = lambda: ga.dijkstra(g, 0)
            elif algo_type == "BFS":
                from utils.core import Graph
                from algorithms.graph import GraphAlgorithms
                g = Graph.from_random(min(size, 100), 0.2)
                ga = GraphAlgorithms()
                func = lambda: ga.bfs(g, 0)
            else:
                import random
                from algorithms.dp import DynamicProgramming
                dp = DynamicProgramming()
                weights = [random.randint(1, 20) for _ in range(min(size, 20))]
                values = [random.randint(10, 100) for _ in range(len(weights))]
                capacity = sum(weights) // 2
                func = lambda: dp.knapsack_01(weights, values, capacity)

            profile = suite.speed_profile(func, warmup=warmup, trials=trials)

        st.success("Profile Complete!")
        metric_row({
            "Min (ms)": f"{profile['min_ms']:.6f}",
            "Max (ms)": f"{profile['max_ms']:.6f}",
            "Mean (ms)": f"{profile['mean_ms']:.6f}",
            "Median (ms)": f"{profile['median_ms']:.6f}",
            "Std Dev": f"{profile['std_ms']:.6f}",
        })

        st.write("All times (ms):", [f"{t:.6f}" for t in profile['all_times']])

        # Distribution plot
        import matplotlib.pyplot as plt
        fig, ax = plt.subplots(figsize=(10, 4), facecolor='#0f172a')
        ax.set_facecolor('#0f172a')
        ax.hist(profile['all_times'], bins=min(trials, 20), color='#06b6d4', edgecolor='white', alpha=0.8)
        ax.axvline(profile['mean_ms'], color='#ef4444', linestyle='--', linewidth=2, label=f'Mean: {profile["mean_ms"]:.4f}')
        ax.axvline(profile['median_ms'], color='#10b981', linestyle='--', linewidth=2, label=f'Median: {profile["median_ms"]:.4f}')
        ax.set_title(f"Execution Time Distribution — {algo_type}", color='#22d3ee', fontsize=14, fontweight='bold')
        ax.set_xlabel("Time (ms)", color='#94a3b8')
        ax.set_ylabel("Frequency", color='#94a3b8')
        ax.legend(facecolor='#1e293b', edgecolor='#334155', labelcolor='#94a3b8')
        ax.tick_params(colors='#94a3b8')
        for spine in ax.spines.values():
            spine.set_color('#334155')
        plt.tight_layout()
        st.pyplot(fig)

theory_box("Benchmarking Best Practices", 
    "<strong>Warmup runs</strong> eliminate JIT compilation and cache effects.<br>"
    "<strong>Multiple trials</strong> account for OS scheduling noise.<br>"
    "<strong>Report median</strong> instead of mean for skewed distributions.<br>"
    "<strong>Remove outliers</strong> (>3σ) caused by garbage collection or context switches.",
    "info")

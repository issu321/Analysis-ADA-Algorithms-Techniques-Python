"""
USSU Algorithm Analyzer v4.0 - Backtracking & Branch-Bound Page
N-Queens, Sudoku, Subset Sum, Graph Coloring, Hamiltonian Cycle.
"""
import streamlit as st
import numpy as np
from utils.ui import page_header, algo_card, section_divider, metric_row, theory_box
from algorithms.backtrack import BacktrackingAlgorithms

page_header("BACKTRACKING", "DFS over state space with pruning — exact solutions for NP-hard problems")

bt = BacktrackingAlgorithms()

tabs = st.tabs(["♛ N-Queens", "🧩 Sudoku", "🎯 Subset Sum", "🎨 Graph Coloring", "🔄 Hamiltonian Cycle"])

with tabs[0]:
    st.subheader("N-Queens Problem")
    n = st.slider("Board Size (n)", 4, 12, 8)

    if st.button("▶️ Solve N-Queens", use_container_width=True):
        with st.spinner(f"Solving {n}-Queens..."):
            result = bt.n_queens(n)
        st.success(f"Found {result['solutions_found']} solution(s)")
        metric_row({
            "Time (ms)": f"{result.get('execution_time_ms', 0):.4f}",
            "Recursions": result['recursions'],
            "Comparisons": result['comparisons'],
        })

        if result['first_solution']:
            board = result['first_solution']
            # Visualize board
            fig_data = np.array(board)
            st.write("**First Solution:**")

            # Custom chess board visualization
            import matplotlib.pyplot as plt
            fig, ax = plt.subplots(figsize=(6, 6), facecolor='#0f172a')
            ax.set_facecolor('#0f172a')

            for i in range(n):
                for j in range(n):
                    color = '#1e293b' if (i+j) % 2 == 0 else '#334155'
                    ax.add_patch(plt.Rectangle((j, n-1-i), 1, 1, facecolor=color, edgecolor='#475569'))
                    if board[i][j] == 1:
                        ax.text(j+0.5, n-1-i+0.5, '♛', ha='center', va='center', 
                               fontsize=28, color='#06b6d4', fontweight='bold')

            ax.set_xlim(0, n)
            ax.set_ylim(0, n)
            ax.set_xticks(range(n))
            ax.set_yticks(range(n))
            ax.set_xticklabels([str(i) for i in range(n)], color='#94a3b8')
            ax.set_yticklabels([str(n-1-i) for i in range(n)], color='#94a3b8')
            ax.set_aspect('equal')
            ax.tick_params(colors='#94a3b8')
            for spine in ax.spines.values():
                spine.set_color('#334155')
            plt.title(f"{n}-Queens Solution", color='#22d3ee', fontsize=16, fontweight='bold', pad=15)
            plt.tight_layout()
            st.pyplot(fig)

with tabs[1]:
    st.subheader("Sudoku Solver")
    preset = st.selectbox("Preset", ["Easy", "Medium", "Hard", "Custom"])

    if preset == "Easy":
        grid = [
            [5,3,0,0,7,0,0,0,0],
            [6,0,0,1,9,5,0,0,0],
            [0,9,8,0,0,0,0,6,0],
            [8,0,0,0,6,0,0,0,3],
            [4,0,0,8,0,3,0,0,1],
            [7,0,0,0,2,0,0,0,6],
            [0,6,0,0,0,0,2,8,0],
            [0,0,0,4,1,9,0,0,5],
            [0,0,0,0,8,0,0,7,9]
        ]
    elif preset == "Medium":
        grid = [
            [0,0,0,6,0,0,4,0,0],
            [7,0,0,0,0,3,6,0,0],
            [0,0,0,0,9,1,0,8,0],
            [0,0,0,0,0,0,0,0,0],
            [0,5,0,1,8,0,0,0,3],
            [0,0,0,3,0,6,0,4,5],
            [0,4,0,2,0,0,0,6,0],
            [9,0,3,0,0,0,0,0,0],
            [0,2,0,0,0,0,1,0,0]
        ]
    elif preset == "Hard":
        grid = [
            [0,0,0,0,0,0,0,0,0],
            [0,0,0,0,0,3,0,8,5],
            [0,0,1,0,2,0,0,0,0],
            [0,0,0,5,0,7,0,0,0],
            [0,0,4,0,0,0,1,0,0],
            [0,9,0,0,0,0,0,0,0],
            [5,0,0,0,0,0,0,7,3],
            [0,0,2,0,1,0,0,0,0],
            [0,0,0,0,4,0,0,0,9]
        ]
    else:
        grid_str = st.text_area("Enter 9x9 grid (0 for empty, rows separated by newlines, cells by space)",
                                "5 3 0 0 7 0 0 0 0\n6 0 0 1 9 5 0 0 0\n0 9 8 0 0 0 0 6 0\n8 0 0 0 6 0 0 0 3\n4 0 0 8 0 3 0 0 1\n7 0 0 0 2 0 0 0 6\n0 6 0 0 0 0 2 8 0\n0 0 0 4 1 9 0 0 5\n0 0 0 0 8 0 0 7 9", height=150)
        grid = [list(map(int, row.split())) for row in grid_str.strip().split('\n')]

    # Display input grid
    st.write("Input Puzzle:")
    st.dataframe(grid, use_container_width=True)

    if st.button("▶️ Solve Sudoku", use_container_width=True):
        with st.spinner("Solving..."):
            result = bt.sudoku_solver([row[:] for row in grid])  # Deep copy
        if result['solved']:
            st.success("Sudoku Solved!")
            st.write("Solution:")
            st.dataframe(result['grid'], use_container_width=True)
        else:
            st.error("No solution exists for this puzzle")
        metric_row({
            "Time (ms)": f"{result.get('execution_time_ms', 0):.4f}",
            "Recursions": result['recursions'],
            "Comparisons": result['comparisons'],
        })

with tabs[2]:
    st.subheader("Subset Sum Problem")
    arr_str = st.text_input("Array", "3 34 4 12 5 2")
    arr = list(map(int, arr_str.split()))
    target = st.number_input("Target Sum", value=9)

    if st.button("▶️ Find Subsets", use_container_width=True):
        with st.spinner("Searching..."):
            result = bt.subset_sum(arr, target)
        st.success(f"Found {result['count']} subset(s) that sum to {target}")
        for i, subset in enumerate(result['subsets']):
            st.code(f"Subset {i+1}: {subset} = {sum(subset)}")
        metric_row({
            "Time (ms)": f"{result.get('execution_time_ms', 0):.4f}",
            "Recursions": result['recursions'],
        })

with tabs[3]:
    st.subheader("Graph Coloring (Backtracking)")
    n_nodes = st.slider("Nodes", 3, 10, 4)
    m_colors = st.slider("Max Colors", 2, 5, 3)

    if st.button("🎲 Generate Random Graph", use_container_width=True, key="color_rand"):
        import random
        adj = [[0]*n_nodes for _ in range(n_nodes)]
        for i in range(n_nodes):
            for j in range(i+1, n_nodes):
                if random.random() < 0.5:
                    adj[i][j] = adj[j][i] = 1
        st.session_state['color_adj'] = adj
        st.rerun()

    adj = st.session_state.get('color_adj', [[0,1,1,1],[1,0,1,0],[1,1,0,1],[1,0,1,0]])
    st.write("Adjacency Matrix:")
    st.dataframe(adj, use_container_width=True)

    if st.button("▶️ Color Graph", use_container_width=True):
        with st.spinner("Coloring..."):
            result = bt.graph_coloring(adj, m_colors)
        if result['possible']:
            st.success(f"Colorable with {result['colors_needed']} colors!")
            st.write("Color assignment:", result['coloring'])
            # Visualize
            import matplotlib.pyplot as plt
            import networkx as nx
            fig, ax = plt.subplots(figsize=(6, 6), facecolor='#0f172a')
            G = nx.Graph()
            for i in range(n_nodes):
                G.add_node(i)
            for i in range(n_nodes):
                for j in range(n_nodes):
                    if adj[i][j]:
                        G.add_edge(i, j)
            colors = ['#06b6d4', '#8b5cf6', '#10b981', '#f59e0b', '#ef4444']
            node_colors = [colors[result['coloring'][i] % len(colors)] for i in range(n_nodes)]
            pos = nx.spring_layout(G, seed=42)
            nx.draw(G, pos, node_color=node_colors, with_labels=True, font_color='white',
                   edge_color='#475569', ax=ax, node_size=800, linewidths=2)
            ax.set_title("Graph Coloring", color='#22d3ee', fontsize=14, fontweight='bold')
            plt.tight_layout()
            st.pyplot(fig)
        else:
            st.error(f"Not colorable with {m_colors} colors")
        metric_row({
            "Time (ms)": f"{result.get('execution_time_ms', 0):.4f}",
            "Recursions": result['recursions'],
        })

with tabs[4]:
    st.subheader("Hamiltonian Cycle")
    n_nodes = st.slider("Nodes", 3, 10, 5, key="ham_n")
    start = st.number_input("Start Node", min_value=0, max_value=n_nodes-1, value=0)

    if st.button("🎲 Generate Random Graph", use_container_width=True, key="ham_rand"):
        import random
        adj = [[0]*n_nodes for _ in range(n_nodes)]
        for i in range(n_nodes):
            for j in range(i+1, n_nodes):
                if random.random() < 0.6:
                    adj[i][j] = adj[j][i] = 1
        st.session_state['ham_adj'] = adj
        st.rerun()

    adj = st.session_state.get('ham_adj', [[0,1,0,1,0],[1,0,1,1,1],[0,1,0,1,0],[1,1,1,0,1],[0,1,0,1,0]])
    st.write("Adjacency Matrix:")
    st.dataframe(adj, use_container_width=True)

    if st.button("▶️ Find Hamiltonian Cycle", use_container_width=True):
        with st.spinner("Searching..."):
            result = bt.hamiltonian_cycle(adj, start)
        if result['found']:
            st.success(f"Cycle found: {' → '.join(map(str, result['cycle']))}")
        else:
            st.error("No Hamiltonian cycle exists")
        metric_row({
            "Time (ms)": f"{result.get('execution_time_ms', 0):.4f}",
            "Recursions": result['recursions'],
            "Comparisons": result['comparisons'],
        })

theory_box("Backtracking Complexity", 
    "Backtracking explores the <strong>state space tree</strong> depth-first, pruning branches that violate constraints. "
    "Worst-case time is exponential, but pruning can dramatically reduce the search space in practice. "
    "<strong>Branch & Bound</strong> extends backtracking with bounds to prune suboptimal partial solutions.",
    "info")

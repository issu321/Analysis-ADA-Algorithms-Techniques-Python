"""
USSU Algorithm Analyzer v4.0 - Greedy Algorithms Page
Activity Selection, Fractional Knapsack, Huffman Coding, Job Sequencing.
"""
import streamlit as st
import random
from utils.ui import page_header, algo_card, section_divider, metric_row, theory_box
from algorithms.greedy import GreedyAlgorithms

page_header("GREEDY ALGORITHMS", "Locally optimal choices leading to globally optimal solutions")

greedy = GreedyAlgorithms()

tabs = st.tabs(["📅 Activity Selection", "🎒 Fractional Knapsack", "📡 Huffman Coding", "💼 Job Sequencing", "🪙 Min Coins"])

with tabs[0]:
    st.subheader("Activity Selection Problem")
    n_acts = st.slider("Number of Activities", 3, 15, 6)

    if st.button("🎲 Generate Random Activities", use_container_width=True):
        acts = []
        for i in range(n_acts):
            start = random.randint(1, 20)
            finish = start + random.randint(1, 8)
            acts.append((start, finish, f"A{i+1}"))
        st.session_state['activities'] = acts
        st.rerun()

    acts = st.session_state.get('activities', [(1, 4, 'A1'), (3, 5, 'A2'), (0, 6, 'A3'), (5, 7, 'A4'), (8, 9, 'A5'), (5, 9, 'A6')])

    st.write("Activities (start, finish, name):")
    st.write(acts)

    if st.button("▶️ Select Activities (Greedy)", use_container_width=True):
        with st.spinner("Selecting..."):
            result = greedy.activity_selection(acts)
        st.success(f"Selected {result['count']} activities: {[a[2] for a in result['selected']]}")
        st.write("Selected details:", result['selected'])
        metric_row({
            "Time (ms)": f"{result.get('execution_time_ms', 0):.4f}",
            "Iterations": result['iterations'],
            "Comparisons": result['comparisons'],
        })

with tabs[1]:
    st.subheader("Fractional Knapsack")
    n_items = st.slider("Items", 3, 10, 5, key="frac_n")
    capacity = st.slider("Capacity", 10, 100, 50, key="frac_cap")

    if st.button("🎲 Random Items", use_container_width=True, key="frac_rand"):
        weights = [random.randint(5, 20) for _ in range(n_items)]
        values = [random.randint(10, 100) for _ in range(n_items)]
        st.session_state['frac_weights'] = weights
        st.session_state['frac_values'] = values
        st.rerun()

    weights = st.session_state.get('frac_weights', [10, 20, 30])
    values = st.session_state.get('frac_values', [60, 100, 120])

    c1, c2 = st.columns(2)
    with c1:
        weights = list(map(int, st.text_input("Weights", " ".join(map(str, weights))).split()))
    with c2:
        values = list(map(int, st.text_input("Values", " ".join(map(str, values))).split()))

    if st.button("▶️ Solve Fractional Knapsack", use_container_width=True):
        with st.spinner("Solving..."):
            result = greedy.fractional_knapsack(weights, values, capacity)
        st.success(f"Max Value: {result['max_value']:.2f}")
        st.write("Selected items (index, fraction, value):", result['selected_items'])
        metric_row({
            "Time (ms)": f"{result.get('execution_time_ms', 0):.4f}",
            "Iterations": result['iterations'],
        })

with tabs[2]:
    st.subheader("Huffman Coding")
    text = st.text_input("Input Text", "abracadabra")

    if st.button("▶️ Generate Huffman Codes", use_container_width=True):
        from collections import Counter
        freq = Counter(text)
        with st.spinner("Building tree..."):
            result = greedy.huffman_coding(dict(freq))
        st.success(f"Total bits: {result['total_bits']} | Average: {result['average_bits']:.2f}")
        st.write("Codes:")
        for char, code in result['codes'].items():
            st.code(f"'{char}': {code} (freq: {freq[char]})")
        metric_row({
            "Time (ms)": f"{result.get('execution_time_ms', 0):.4f}",
            "Iterations": result['iterations'],
        })

with tabs[3]:
    st.subheader("Job Sequencing with Deadlines")
    n_jobs = st.slider("Jobs", 3, 10, 5, key="job_n")

    if st.button("🎲 Random Jobs", use_container_width=True, key="job_rand"):
        jobs = []
        for i in range(n_jobs):
            deadline = random.randint(1, n_jobs)
            profit = random.randint(10, 100)
            jobs.append((f"J{i+1}", deadline, profit))
        st.session_state['jobs'] = jobs
        st.rerun()

    jobs = st.session_state.get('jobs', [('J1', 2, 60), ('J2', 1, 100), ('J3', 3, 20), ('J4', 2, 40), ('J5', 1, 20)])
    st.write("Jobs (id, deadline, profit):", jobs)

    if st.button("▶️ Schedule Jobs", use_container_width=True):
        with st.spinner("Scheduling..."):
            result = greedy.job_sequencing(jobs)
        st.success(f"Total Profit: {result['total_profit']} | Scheduled: {[j[0] for j in result['scheduled_jobs']]}")
        st.write("Schedule (job, time slot):", result['scheduled_jobs'])
        metric_row({
            "Time (ms)": f"{result.get('execution_time_ms', 0):.4f}",
            "Iterations": result['iterations'],
        })

with tabs[4]:
    st.subheader("Minimum Coins (Greedy)")
    coins = st.text_input("Coin Denominations", "1 2 5 10 20 50")
    coins = list(map(int, coins.split()))
    amount = st.number_input("Amount", min_value=1, value=93)

    if st.button("▶️ Greedy Coin Change", use_container_width=True):
        with st.spinner("Computing..."):
            result = greedy.minimum_coins_greedy(coins, amount)
        if result['warning']:
            st.warning(result['warning'])
        st.success(f"Min Coins: {result['min_coins']} | Used: {result['coins_used']}")
        metric_row({
            "Time (ms)": f"{result.get('execution_time_ms', 0):.4f}",
            "Iterations": result['iterations'],
        })

theory_box("Greedy Choice Property", 
    "A problem has the <strong>greedy choice property</strong> if a globally optimal solution can be reached by making locally optimal choices. "
    "Proof technique: <strong>exchange argument</strong> — show any optimal solution can be transformed into the greedy solution without worsening the objective.",
    "info")

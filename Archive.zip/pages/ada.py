"""
USSU Algorithm Analyzer v4.0 - ADA Theory Page
Master Theorem, Amortized Analysis, NP-Completeness, Asymptotic Notation, Paradigms.
"""
import streamlit as st
import numpy as np
import matplotlib.pyplot as plt
from utils.ui import page_header, section_divider, theory_box, metric_row, algo_card
from utils.viz import plot_asymptotic_growth
from algorithms.ada import ADATools

page_header("ADA THEORY", "Analysis and Design of Algorithms — the theoretical foundation")

ada = ADATools()

tabs = st.tabs(["📐 Asymptotic Notation", "🎓 Master Theorem", "📊 Amortized Analysis", "🔬 NP-Completeness", "🧠 Paradigms"])

with tabs[0]:
    st.subheader("Asymptotic Notation Reference")

    ref = ada.big_o_reference()
    table_html = ["""
    <table style="width:100%; border-collapse:collapse; font-size:13px;">
        <tr style="background:#1e293b; color:#22d3ee;">
            <th style="padding:10px; text-align:left;">Notation</th>
            <th style="padding:10px;">Name</th>
            <th style="padding:10px;">Example</th>
            <th style="padding:10px;">Class</th>
        </tr>
    """]

    for item in ref:
        color = "#10b981" if item['class'] == 'P' else "#f59e0b" if item['class'] == 'NP' else "#ef4444"
        table_html.append(f"""
        <tr style="border-bottom:1px solid #334155;">
            <td style="padding:8px; color:#06b6d4; font-weight:700;">{item['notation']}</td>
            <td style="padding:8px; color:#f8fafc;">{item['name']}</td>
            <td style="padding:8px; color:#94a3b8;">{item['example']}</td>
            <td style="padding:8px; color:{color}; font-weight:700;">{item['class']}</td>
        </tr>
        """)
    table_html.append("</table>")
    st.html("".join(table_html))

    st.markdown("---")
    st.subheader("Formal Definitions")
    defs = ada.asymptotic_definitions()
    for name, definition in defs.items():
        theory_box(name, definition, "info")

    st.markdown("---")
    st.subheader("Growth Comparison")
    fig = plot_asymptotic_growth(max_n=50)
    st.pyplot(fig)

with tabs[1]:
    st.subheader("Master Theorem Solver")
    st.markdown("Solve recurrences of the form: **T(n) = a·T(n/b) + f(n)**")

    col1, col2, col3 = st.columns(3)
    with col1:
        a = st.number_input("a (subproblems)", min_value=1.0, value=2.0, step=1.0)
    with col2:
        b = st.number_input("b (division factor)", min_value=2.0, value=2.0, step=1.0)
    with col3:
        f_n = st.selectbox("f(n)", ["1", "n", "n*log(n)", "n^2", "n^3", "log(n)"])

    if st.button("▶️ Solve Master Theorem", use_container_width=True):
        result = ada.master_theorem(a, b, f_n)
        st.success(f"Solution: {result.solution}")
        st.html(f"""
        <div style="background:rgba(30,41,59,0.9); border:1px solid #8b5cf6; border-radius:12px; padding:16px;">
            <p style="color:#a78bfa; font-weight:700; margin:0 0 8px 0;">Case {result.case}</p>
            <p style="color:#cbd5e1; font-size:14px; line-height:1.6; margin:0;">{result.explanation}</p>
            <p style="color:#94a3b8; font-size:12px; margin-top:8px;">log_b(a) = {result.log_b_a:.4f}</p>
        </div>
        """)

    st.markdown("---")
    st.subheader("Recursion Tree Visualization")
    st.markdown("Level-by-level cost breakdown")

    def f_n_func(n):
        if f_n == "1":
            return 1
        elif f_n == "n":
            return n
        elif f_n == "n*log(n)":
            return n * np.log2(max(n, 1))
        elif f_n == "n^2":
            return n**2
        elif f_n == "n^3":
            return n**3
        elif f_n == "log(n)":
            return np.log2(max(n, 1))
        return n

    if st.button("▶️ Build Recursion Tree", use_container_width=True):
        tree_result = ada.recursion_tree_cost(a, b, f_n_func, 64, levels=6)
        st.write("Level costs:")
        for level in tree_result['tree']:
            st.write(f"Level {level['level']}: {level['nodes']} nodes × subproblem size {level['subproblem_size']:.2f} = cost {level['cost']:.2f}")
        st.info(f"Total approximate cost: {tree_result['total_cost_approx']:.2f}")

with tabs[2]:
    st.subheader("Amortized Analysis")

    amort_tabs = st.tabs(["Dynamic Array", "Binary Counter", "Stack Multipop"])

    with amort_tabs[0]:
        n_ops = st.slider("Operations", 5, 50, 20)
        if st.button("▶️ Analyze Dynamic Array", use_container_width=True):
            result = ada.amortized_dynamic_array(n_ops)
            st.success(f"Total Cost: {result['total_cost']} | Amortized: {result['amortized_cost']:.2f} per op")
            st.write(result['explanation'])
            st.dataframe(result['operations'], use_container_width=True)

    with amort_tabs[1]:
        n_bits = st.slider("Bits", 4, 16, 8, key="am_bits")
        increments = st.slider("Increments", 5, 50, 20, key="am_inc")
        if st.button("▶️ Analyze Binary Counter", use_container_width=True):
            result = ada.amortized_binary_counter(n_bits, increments)
            st.success(f"Total Flips: {result['total_flips']} | Amortized: {result['amortized_per_increment']:.2f} per increment")
            st.write(result['explanation'])
            st.dataframe(result['history'], use_container_width=True)

    with amort_tabs[2]:
        ops_str = st.text_area("Operations (push X, pop, multipop K)", 
                              "push 5\npush 3\npush 7\nmultipop 2\npush 2\npop\npop", height=100)
        ops = ops_str.strip().split("\n")
        if st.button("▶️ Analyze Stack", use_container_width=True):
            result = ada.amortized_stack_multipop(ops)
            st.success(f"Total Amortized Cost: {result['total_amortized_cost']}")
            st.write(result['explanation'])
            st.dataframe(result['history'], use_container_width=True)

with tabs[3]:
    st.subheader("NP-Completeness Reference")
    np_data = ada.np_completeness_reference()

    st.html("<h4 style='color:#22d3ee;'>Complexity Classes</h4>")
    for cls in np_data['complexity_classes']:
        theory_box(f"{cls['class']}", f"<strong>Definition:</strong> {cls['definition']}<<br><strong>Examples:</strong> {', '.join(cls['examples'])}", 
                  "danger" if cls['class'] in ['NP-Hard', 'NP-Complete'] else "info")

    st.html("<h4 style='color:#22d3ee;'>Standard Reductions</h4>")
    table_html = ["""
    <table style="width:100%; border-collapse:collapse; font-size:13px;">
        <tr style="background:#1e293b; color:#22d3ee;">
            <th style="padding:10px;">From</th>
            <th style="padding:10px;">Reduction</th>
            <th style="padding:10px;">To</th>
        </tr>
    """]
    for red in np_data['reductions']:
        table_html.append(f"""
        <tr style="border-bottom:1px solid #334155;">
            <td style="padding:8px; color:#ef4444; text-align:center;">{red['from']}</td>
            <td style="padding:8px; color:#f59e0b; text-align:center; font-weight:700;">{red['type']}</td>
            <td style="padding:8px; color:#10b981; text-align:center;">{red['to']}</td>
        </tr>
        """)
    table_html.append("</table>")
    st.html("".join(table_html))

    st.html("<h4 style='color:#22d3ee;'>Open Problems</h4>")
    for prob in np_data['open_problems']:
        st.html(f"<p style='color:#94a3b8;'>• {prob}</p>")

with tabs[4]:
    st.subheader("Algorithm Design Paradigms")
    paradigms = ada.paradigm_comparison()

    for p in paradigms:
        algo_card(p['paradigm'], "", "", desc=p['approach'])
        st.html(f"""
        <div style="background:rgba(30,41,59,0.6); border-radius:8px; padding:12px; margin-bottom:16px; margin-top:-8px;">
            <p style="color:#a78bfa; font-size:12px; margin:0 0 4px 0;"><strong>Key Property:</strong> {p['key_property']}</p>
            <p style="color:#10b981; font-size:12px; margin:0 0 4px 0;"><strong>When to Use:</strong> {p['when_to_use']}</p>
            <p style="color:#f59e0b; font-size:12px; margin:0 0 4px 0;"><strong>Time Pattern:</strong> {p['time_pattern']}</p>
            <p style="color:#94a3b8; font-size:12px; margin:0;"><strong>Examples:</strong> {', '.join(p['examples'])}</p>
        </div>
        """)

theory_box("Why Theory Matters", 
    "Understanding <strong>asymptotic analysis</strong> prevents premature optimization and helps choose the right algorithm for the data scale. "
    "<strong>Amortized analysis</strong> reveals that expensive operations can be acceptable if they are rare. "
    "<strong>NP-Completeness</strong> theory tells us when to stop looking for polynomial-time exact solutions and switch to approximation or heuristics.",
    "success")
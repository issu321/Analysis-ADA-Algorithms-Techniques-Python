"""
USSU Algorithm Analyzer v4.0 - Compare All Page
Side-by-side algorithm comparison across all categories.
"""
import streamlit as st
import random
import pandas as pd
from utils.ui import page_header, section_divider, metric_row, theory_box
from utils.viz import plot_benchmark_bar
from algorithms.search import SearchingAlgorithms
from algorithms.sort import SortingAlgorithms
from algorithms.graph import GraphAlgorithms
from algorithms.dp import DynamicProgramming
from algorithms.greedy import GreedyAlgorithms
from utils.core import Graph

page_header("COMPARE ALL", "Head-to-head algorithm comparison across every category")

category = st.selectbox("Select Category", [
    "🔍 Searching", "📊 Sorting", "🕸️ Graph Traversal", "📏 Shortest Path", 
    "🌳 MST", "🧩 DP", "💎 Greedy"
])

if category == "🔍 Searching":
    size = st.slider("Array Size", 100, 100000, 10000)
    arr = sorted(random.sample(range(size*2), size))
    target = random.choice(arr)
    searcher = SearchingAlgorithms()

    if st.button("🏁 Run Comparison", use_container_width=True):
        with st.spinner("Benchmarking all search algorithms..."):
            results = searcher.compare_all(arr, target)

        st.success(f"Comparison Complete — Target: {target}")
        valid = [r for r in results if 'error' not in r]

        # Metrics table
        df = pd.DataFrame([{
            'Algorithm': r['name'],
            'Time (ms)': f"{r['time_ms']:.6f}" if r['time_ms'] != float('inf') else 'N/A',
            'Complexity': r['complexity'],
            'Found': 'Yes' if r['found'] else 'No',
            'Index': r['index'],
            'Comparisons': r['comparisons'],
        } for r in valid])
        st.dataframe(df, use_container_width=True)

        # Speed chart
        chart_data = [r for r in valid if r['time_ms'] != float('inf')]
        if chart_data:
            fig = plot_benchmark_bar(chart_data, title="Search Algorithm Speed Comparison")
            st.pyplot(fig)

        # Winner highlight
        fastest = min(chart_data, key=lambda x: x['time_ms'])
        st.balloons()
        st.markdown(f"""
        <div style="background: linear-gradient(90deg, #10b98133, #06b6d433); border: 2px solid #10b981; 
                    border-radius: 16px; padding: 20px; text-align: center; margin-top: 20px;">
            <h2 style="color: #10b981; font-family: 'Orbitron', sans-serif; margin: 0;">🏆 WINNER</h2>
            <p style="color: #f8fafc; font-size: 24px; font-weight: 700; margin: 8px 0;">{fastest['name']}</p>
            <p style="color: #94a3b8; font-size: 16px; margin: 0;">{fastest['time_ms']:.6f} ms | {fastest['complexity']}</p>
        </div>
        """, unsafe_allow_html=True)

elif category == "📊 Sorting":
    size = st.slider("Array Size", 50, 5000, 500)
    arr = [random.randint(0, size) for _ in range(size)]
    sorter = SortingAlgorithms()

    if st.button("🏁 Run Comparison", use_container_width=True):
        with st.spinner("Benchmarking all sort algorithms..."):
            results = sorter.compare_all(arr)

        st.success("Comparison Complete!")
        valid = [r for r in results if 'error' not in r and r['time_ms'] != float('inf')]

        df = pd.DataFrame([{
            'Algorithm': r['name'],
            'Time (ms)': round(r['time_ms'], 4),
            'Time Comp.': r['complexity'],
            'Space': r['space'],
            'Stable': r['stable'],
            'Comparisons': r['comparisons'],
        } for r in valid])
        st.dataframe(df, use_container_width=True)

        if valid:
            fig = plot_benchmark_bar(valid, title="Sort Algorithm Speed Comparison")
            st.pyplot(fig)

        fastest = min(valid, key=lambda x: x['time_ms'])
        st.balloons()
        st.markdown(f"""
        <div style="background: linear-gradient(90deg, #10b98133, #06b6d433); border: 2px solid #10b981; 
                    border-radius: 16px; padding: 20px; text-align: center; margin-top: 20px;">
            <h2 style="color: #10b981; font-family: 'Orbitron', sans-serif; margin: 0;">🏆 WINNER</h2>
            <p style="color: #f8fafc; font-size: 24px; font-weight: 700; margin: 8px 0;">{fastest['name']}</p>
            <p style="color: #94a3b8; font-size: 16px; margin: 0;">{fastest['time_ms']:.4f} ms | {fastest['complexity']} | Stable: {fastest['stable']}</p>
        </div>
        """, unsafe_allow_html=True)

elif category == "🕸️ Graph Traversal":
    n = st.slider("Vertices", 10, 200, 50)
    g = Graph.from_random(n, 0.2, weighted=True)
    start = 0
    ga = GraphAlgorithms()

    if st.button("🏁 Run Comparison", use_container_width=True):
        with st.spinner("Benchmarking graph traversals..."):
            bfs_res = ga.bfs(g, start)
            dfs_res = ga.dfs_iterative(g, start)

        results = [
            {'name': 'BFS', 'time_ms': bfs_res.get('execution_time_ms', 0), 'complexity': 'O(V+E)', 'visited': len(bfs_res.get('visited', set()))},
            {'name': 'DFS (Iter)', 'time_ms': dfs_res.get('execution_time_ms', 0), 'complexity': 'O(V+E)', 'visited': len(dfs_res.get('visited', set()))},
        ]

        df = pd.DataFrame(results)
        st.dataframe(df, use_container_width=True)
        fig = plot_benchmark_bar(results, title="Graph Traversal Comparison")
        st.pyplot(fig)

elif category == "📏 Shortest Path":
    n = st.slider("Vertices", 10, 100, 30)
    g = Graph.from_random(n, 0.3, weighted=True)
    start = 0
    ga = GraphAlgorithms()

    if st.button("🏁 Run Comparison", use_container_width=True):
        with st.spinner("Benchmarking shortest path algorithms..."):
            dij_res = ga.dijkstra(g, start)
            bf_res = ga.bellman_ford(g, start)
            fw_res = ga.floyd_warshall(g)

        results = [
            {'name': 'Dijkstra', 'time_ms': dij_res.get('execution_time_ms', 0), 'complexity': 'O((V+E) log V)'},
            {'name': 'Bellman-Ford', 'time_ms': bf_res.get('execution_time_ms', 0), 'complexity': 'O(V×E)'},
            {'name': 'Floyd-Warshall', 'time_ms': fw_res.get('execution_time_ms', 0), 'complexity': 'O(V³)'},
        ]

        df = pd.DataFrame(results)
        st.dataframe(df, use_container_width=True)
        fig = plot_benchmark_bar(results, title="Shortest Path Algorithm Comparison")
        st.pyplot(fig)

elif category == "🌳 MST":
    n = st.slider("Vertices", 10, 100, 30)
    g = Graph.from_random(n, 0.3, weighted=False, directed=False)
    ga = GraphAlgorithms()

    if st.button("🏁 Run Comparison", use_container_width=True):
        with st.spinner("Benchmarking MST algorithms..."):
            prim_res = ga.prim_mst(g)
            krus_res = ga.kruskal_mst(g)

        results = [
            {'name': "Prim's", 'time_ms': prim_res.get('execution_time_ms', 0), 'complexity': 'O((V+E) log V)', 'weight': prim_res.get('total_weight', 0)},
            {'name': "Kruskal's", 'time_ms': krus_res.get('execution_time_ms', 0), 'complexity': 'O(E log E)', 'weight': krus_res.get('total_weight', 0)},
        ]

        df = pd.DataFrame(results)
        st.dataframe(df, use_container_width=True)
        fig = plot_benchmark_bar(results, title="MST Algorithm Comparison")
        st.pyplot(fig)

elif category == "🧩 DP":
    size = st.slider("Problem Size", 5, 20, 10)
    dp = DynamicProgramming()

    if st.button("🏁 Run Comparison", use_container_width=True):
        with st.spinner("Benchmarking DP algorithms..."):
            weights = [random.randint(1, 10) for _ in range(size)]
            values = [random.randint(10, 100) for _ in range(size)]
            capacity = sum(weights) // 2
            knap_res = dp.knapsack_01(weights, values, capacity)

            s1 = ''.join(random.choices('ABCDEFGHIJ', k=size))
            s2 = ''.join(random.choices('ABCDEFGHIJ', k=size))
            lcs_res = dp.lcs(s1, s2)

            dims = [random.randint(5, 20) for _ in range(size+1)]
            chain_res = dp.matrix_chain_order(dims)

        results = [
            {'name': '0/1 Knapsack', 'time_ms': knap_res.get('execution_time_ms', 0), 'complexity': 'O(n×W)'},
            {'name': 'LCS', 'time_ms': lcs_res.get('execution_time_ms', 0), 'complexity': 'O(m×n)'},
            {'name': 'Matrix Chain', 'time_ms': chain_res.get('execution_time_ms', 0), 'complexity': 'O(n³)'},
        ]

        df = pd.DataFrame(results)
        st.dataframe(df, use_container_width=True)
        fig = plot_benchmark_bar(results, title="DP Algorithm Comparison")
        st.pyplot(fig)

elif category == "💎 Greedy":
    size = st.slider("Problem Size", 5, 20, 10)
    greedy = GreedyAlgorithms()

    if st.button("🏁 Run Comparison", use_container_width=True):
        with st.spinner("Benchmarking greedy algorithms..."):
            acts = [(random.randint(1, 20), random.randint(1, 20)+random.randint(1, 8), f"A{i}") for i in range(size)]
            act_res = greedy.activity_selection(acts)

            weights = [random.randint(5, 20) for _ in range(size)]
            values = [random.randint(10, 100) for _ in range(size)]
            capacity = sum(weights) // 2
            frac_res = greedy.fractional_knapsack(weights, values, capacity)

            from collections import Counter
            text = ''.join(random.choices('abcdefgh', k=size*3))
            freq = Counter(text)
            huff_res = greedy.huffman_coding(dict(freq))

        results = [
            {'name': 'Activity Selection', 'time_ms': act_res.get('execution_time_ms', 0), 'complexity': 'O(n log n)'},
            {'name': 'Fractional Knapsack', 'time_ms': frac_res.get('execution_time_ms', 0), 'complexity': 'O(n log n)'},
            {'name': 'Huffman Coding', 'time_ms': huff_res.get('execution_time_ms', 0), 'complexity': 'O(n log n)'},
        ]

        df = pd.DataFrame(results)
        st.dataframe(df, use_container_width=True)
        fig = plot_benchmark_bar(results, title="Greedy Algorithm Comparison")
        st.pyplot(fig)

theory_box("Algorithm Selection Guide", 
    "<strong>Searching:</strong> Use Binary Search for sorted data, Hash Tables for O(1) average.<br>"
    "<strong>Sorting:</strong> Use Timsort (Python default) for general purpose, Counting/Radix for integers.<br>"
    "<strong>Graphs:</strong> Dijkstra for positive weights, Bellman-Ford for negatives, Floyd-Warshall for all-pairs.<br>"
    "<strong>Optimization:</strong> Greedy when greedy choice property holds, DP for overlapping subproblems.<br>"
    "<strong>Exact NP-hard:</strong> Backtracking for small instances, approximation for large ones.",
    "success")

"""
USSU Algorithm Analyzer v4.0 - Searching Algorithms Page
Interactive searching with step-by-step metrics and benchmark comparison.
"""
import streamlit as st
import random
from utils.ui import page_header, algo_card, section_divider, metric_row, result_box, theory_box
from utils.viz import plot_benchmark_bar
from algorithms.search import SearchingAlgorithms

page_header("SEARCHING ALGORITHMS", "Linear, Binary, Jump, Interpolation, Exponential, Ternary, Fibonacci")

searcher = SearchingAlgorithms()

# Input section
st.html("<h3 style='color:#22d3ee; font-family:Orbitron; margin-top:0;'>🔧 Input Configuration</h3>")
col1, col2 = st.columns([2, 1])
with col1:
    input_mode = st.radio("Array Source", ["Manual Entry", "Random Generate"], horizontal=True)
    if input_mode == "Manual Entry":
        arr_input = st.text_input("Sorted numbers (space separated)", "1 3 5 7 9 11 13 15 17 19 21 23 25")
        arr = list(map(int, arr_input.split()))
    else:
        size = st.slider("Array Size", 10, 10000, 100)
        max_val = st.slider("Max Value", size, size*10, size*2)
        arr = sorted(random.sample(range(max_val), size))
        st.write(f"Generated {len(arr)} elements")
with col2:
    target = st.number_input("Target Value", value=arr[len(arr)//2] if arr else 0)
    st.caption(f"Array range: {min(arr)} to {max(arr)}")

# Individual algorithm execution
section_divider("RUN ALGORITHMS")

algo_cols = st.columns(4)
algorithms = [
    ("Linear Search", "O(n)", "O(1)", searcher.linear_search),
    ("Binary Search", "O(log n)", "O(1)", searcher.binary_search_iterative),
    ("Jump Search", "O(√n)", "O(1)", searcher.jump_search),
    ("Interpolation", "O(log log n)", "O(1)", searcher.interpolation_search),
    ("Exponential", "O(log n)", "O(1)", searcher.exponential_search),
    ("Ternary Search", "O(log₃ n)", "O(1)", searcher.ternary_search),
    ("Fibonacci", "O(log n)", "O(1)", searcher.fibonacci_search),
    ("Binary (Rec)", "O(log n)", "O(log n)", searcher.binary_search_recursive),
]

for i, (name, time_c, space_c, func) in enumerate(algorithms):
    with algo_cols[i % 4]:
        algo_card(name, time_c, space_c, desc="")
        if st.button(f"▶️ Run {name}", key=f"search_{i}", use_container_width=True):
            with st.spinner(f"Running {name}..."):
                result = func(arr, target)

            status = "✅ FOUND" if result['found'] else "❌ NOT FOUND"
            color = "#10b981" if result['found'] else "#ef4444"
            st.html(f"""
            <div style="background:rgba(30,41,59,0.9); border:1px solid {color}; border-radius:8px; padding:10px; margin-top:8px;">
                <p style="color:{color}; font-weight:700; margin:0;">{status} at index {result['index']}</p>
                <p style="color:#94a3b8; font-size:11px; margin:4px 0 0 0;">
                    Time: {result['execution_time_ms']:.4f}ms | Comp: {result['comparisons']} | Access: {result['accesses']}
                </p>
            </div>
            """)

# Benchmark section
section_divider("BENCHMARK SUITE")

if st.button("🏁 Compare All Searching Algorithms", use_container_width=True):
    with st.spinner("Benchmarking all algorithms..."):
        results = searcher.compare_all(arr, target)

    st.success("Benchmark Complete!")

    # Build complete table HTML in one block
    table_rows = []
    table_rows.append("""
    <table style="width:100%; border-collapse:collapse; font-size:13px;">
        <tr style="background:#1e293b; color:#22d3ee;">
            <th style="padding:10px; text-align:left;">Algorithm</th>
            <th style="padding:10px;">Time (ms)</th>
            <th style="padding:10px;">Complexity</th>
            <th style="padding:10px;">Found</th>
            <th style="padding:10px;">Comparisons</th>
        </tr>
    """)

    for r in results:
        if 'error' in r:
            continue
        found_icon = "✅" if r['found'] else "❌"
        time_str = f"{r['time_ms']:.6f}" if r['time_ms'] != float('inf') else "∞"
        table_rows.append(f"""
        <tr style="border-bottom:1px solid #334155;">
            <td style="padding:8px; color:#f8fafc;">{r['name']}</td>
            <td style="padding:8px; color:#06b6d4; text-align:center;">{time_str}</td>
            <td style="padding:8px; color:#a78bfa; text-align:center;">{r['complexity']}</td>
            <td style="padding:8px; text-align:center;">{found_icon}</td>
            <td style="padding:8px; color:#f59e0b; text-align:center;">{r['comparisons']}</td>
        </tr>
        """)

    table_rows.append("</table>")
    st.html("".join(table_rows))

    # Chart
    valid_results = [r for r in results if 'error' not in r and r['time_ms'] != float('inf')]
    if valid_results:
        fig = plot_benchmark_bar(valid_results, title="Search Algorithm Speed Comparison")
        st.pyplot(fig)

theory_box("Searching Theory", 
    "<strong>Binary Search</strong> requires sorted input and achieves O(log n) by halving the search space each iteration.<br>"
    "<strong>Interpolation Search</strong> estimates position using value distribution — best for uniformly distributed data.<br>"
    "<strong>Jump Search</strong> checks elements at intervals of √n, then linear searches the block.<br>"
    "<strong>Exponential Search</strong> finds range by repeated doubling, then binary searches within it.",
    "info")
"""
USSU Algorithm Analyzer v4.0 - Dynamic Programming Page
Knapsack, LCS, Edit Distance, Matrix Chain, Coin Change, LIS with DP tables.
"""
import streamlit as st
import random
from utils.ui import page_header, algo_card, section_divider, metric_row, theory_box
from utils.viz import plot_dp_table
from algorithms.dp import DynamicProgramming

page_header("DYNAMIC PROGRAMMING", "Optimal substructure + Overlapping subproblems = DP power")

dp = DynamicProgramming()

# DP Tabs
tabs = st.tabs(["🎒 Knapsack", "🔤 LCS", "✏️ Edit Distance", "🔗 Matrix Chain", "🪙 Coin Change", "📈 LIS"])

with tabs[0]:
    st.subheader("0/1 Knapsack Problem")
    col1, col2 = st.columns(2)
    with col1:
        n_items = st.slider("Items", 3, 15, 5)
        capacity = st.slider("Capacity", 5, 50, 15)
    with col2:
        if st.button("🎲 Random Items", use_container_width=True):
            st.session_state['dp_weights'] = [random.randint(1, 10) for _ in range(n_items)]
            st.session_state['dp_values'] = [random.randint(10, 100) for _ in range(n_items)]
            st.rerun()

    weights = st.session_state.get('dp_weights', [2, 3, 4, 5])
    values = st.session_state.get('dp_values', [3, 4, 5, 6])

    c1, c2 = st.columns(2)
    with c1:
        weights = st.text_input("Weights (space)", " ".join(map(str, weights)))
        weights = list(map(int, weights.split()))
    with c2:
        values = st.text_input("Values (space)", " ".join(map(str, values)))
        values = list(map(int, values.split()))

    if st.button("▶️ Solve 0/1 Knapsack", use_container_width=True):
        with st.spinner("Solving..."):
            result = dp.knapsack_01(weights, values, capacity)
        st.success(f"Max Value: {result['max_value']} | Selected: {result['selected_items']}")
        metric_row({
            "Time (ms)": f"{result.get('execution_time_ms', 0):.4f}",
            "Iterations": result['iterations'],
            "Comparisons": result['comparisons'],
        })
        if len(weights) <= 10 and capacity <= 20:
            fig = plot_dp_table(result['dp_table'], title="DP Table: 0/1 Knapsack",
                               row_labels=[f"Item {i}" for i in range(len(weights)+1)],
                               col_labels=[f"Cap {w}" for w in range(capacity+1)])
            st.pyplot(fig)

    st.markdown("---")
    st.subheader("Unbounded Knapsack")
    if st.button("▶️ Solve Unbounded Knapsack", use_container_width=True):
        with st.spinner("Solving..."):
            result = dp.knapsack_unbounded(weights, values, capacity)
        st.success(f"Max Value: {result['max_value']} | Items used: {result['items_used']}")
        metric_row({
            "Time (ms)": f"{result.get('execution_time_ms', 0):.4f}",
            "Iterations": result['iterations'],
        })

with tabs[1]:
    st.subheader("Longest Common Subsequence")
    c1, c2 = st.columns(2)
    with c1:
        s1 = st.text_input("String 1", "ABCDGH")
    with c2:
        s2 = st.text_input("String 2", "AEDFHR")

    if st.button("▶️ Find LCS", use_container_width=True):
        with st.spinner("Computing LCS..."):
            result = dp.lcs(s1, s2)
        st.success(f"LCS Length: {result['length']} | Subsequence: '{result['subsequence']}'")
        metric_row({
            "Time (ms)": f"{result.get('execution_time_ms', 0):.4f}",
            "Iterations": result['iterations'],
            "Comparisons": result['comparisons'],
        })
        if len(s1) <= 10 and len(s2) <= 10:
            fig = plot_dp_table(result['dp_table'], title="DP Table: LCS",
                               row_labels=[''] + list(s1), col_labels=[''] + list(s2))
            st.pyplot(fig)

with tabs[2]:
    st.subheader("Edit Distance (Levenshtein)")
    c1, c2 = st.columns(2)
    with c1:
        s1 = st.text_input("Source", "kitten", key="ed_s1")
    with c2:
        s2 = st.text_input("Target", "sitting", key="ed_s2")

    if st.button("▶️ Compute Edit Distance", use_container_width=True):
        with st.spinner("Computing..."):
            result = dp.edit_distance(s1, s2)
        st.success(f"Edit Distance: {result['distance']}")
        st.write("Operations:", result['operations'])
        metric_row({
            "Time (ms)": f"{result.get('execution_time_ms', 0):.4f}",
            "Iterations": result['iterations'],
        })
        if len(s1) <= 10 and len(s2) <= 10:
            fig = plot_dp_table(result['dp_table'], title="DP Table: Edit Distance",
                               row_labels=[''] + list(s1), col_labels=[''] + list(s2))
            st.pyplot(fig)

with tabs[3]:
    st.subheader("Matrix Chain Multiplication")
    dims_str = st.text_input("Dimensions (space separated)", "10 30 5 60")
    dims = list(map(int, dims_str.split()))

    if st.button("▶️ Optimize Parenthesization", use_container_width=True):
        with st.spinner("Computing..."):
            result = dp.matrix_chain_order(dims)
        st.success(f"Min Multiplications: {result['min_multiplications']}")
        st.code(f"Optimal: {result['optimal_parenthesization']}")
        metric_row({
            "Time (ms)": f"{result.get('execution_time_ms', 0):.4f}",
            "Iterations": result['iterations'],
        })
        if len(dims) <= 6:
            fig = plot_dp_table(result['dp_table'], title="DP Table: Matrix Chain",
                               row_labels=[f"A{i+1}" for i in range(len(dims)-1)],
                               col_labels=[f"A{j+1}" for j in range(len(dims)-1)])
            st.pyplot(fig)

with tabs[4]:
    st.subheader("Coin Change")
    c1, c2 = st.columns(2)
    with c1:
        coins = st.text_input("Coins", "1 2 5")
        coins = list(map(int, coins.split()))
    with c2:
        amount = st.number_input("Amount", min_value=1, value=11)

    col1, col2 = st.columns(2)
    with col1:
        if st.button("▶️ Min Coins (DP)", use_container_width=True):
            with st.spinner("Solving..."):
                result = dp.coin_change_min(coins, amount)
            if result['min_coins'] == -1:
                st.error("Cannot make amount with given coins")
            else:
                st.success(f"Min Coins: {result['min_coins']} | Used: {result['coins_used']}")
                metric_row({"Time (ms)": f"{result.get('execution_time_ms', 0):.4f}", "Iterations": result['iterations']})
    with col2:
        if st.button("▶️ Count Ways (DP)", use_container_width=True):
            with st.spinner("Counting..."):
                result = dp.coin_change_ways(coins, amount)
            st.success(f"Number of Ways: {result['ways']}")
            metric_row({"Time (ms)": f"{result.get('execution_time_ms', 0):.4f}", "Iterations": result['iterations']})

with tabs[5]:
    st.subheader("Longest Increasing Subsequence")
    arr_str = st.text_input("Array", "10 22 9 33 21 50 41 60")
    arr = list(map(int, arr_str.split()))

    if st.button("▶️ Find LIS", use_container_width=True):
        with st.spinner("Computing..."):
            result = dp.lis(arr)
        st.success(f"LIS Length: {result['length']} | Subsequence: {result['subsequence']}")
        metric_row({
            "Time (ms)": f"{result.get('execution_time_ms', 0):.4f}",
            "Iterations": result['iterations'],
            "Comparisons": result['comparisons'],
        })

theory_box("DP Paradigm", 
    "<strong>Optimal Substructure:</strong> Optimal solution contains optimal solutions to subproblems.<br>"
    "<strong>Overlapping Subproblems:</strong> Recursive solution solves same subproblems repeatedly.<br>"
    "<strong>Memoization (Top-Down):</strong> Store results of recursive calls.<br>"
    "<strong>Tabulation (Bottom-Up):</strong> Fill table iteratively from base cases.",
    "info")

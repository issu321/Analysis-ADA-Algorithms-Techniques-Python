@echo off
title USSU Algorithm Analyzer v4.0 - Terminal Mode
echo.
echo  USSU Algorithm Analyzer v4.0 - Terminal CLI
echo.

if exist "venv\Scripts\python.exe" (
    venv\Scripts\python.exe app_cli.py
) else (
    python app_cli.py
)

"""
================================================================================
  USSU'S ULTRA PRO MAX ALGORITHM ANALYZER v4.0
  Streamlit Cyberpunk Edition

  Complete analysis of Graph Algorithms, Searching, Sorting, MST, Shortest Path,
  Dynamic Programming, Greedy, Backtracking, ADA Theory, Math Tools,
  Speed Benchmarking | Performance Profiling | Futuristic UI

  Author: Ussu (github.com/issu321)
  Kali Linux Compatible | Python 3.13 Ready | Windows 11 Ready
================================================================================
"""
import streamlit as st
from utils.core import CyberCSS
from utils.ui import sidebar_branding, footer

# Page config must be first st call
st.set_page_config(
    page_title="USSU Algorithm Analyzer v4.0",
    page_icon="⚡",
    layout="wide",
    initial_sidebar_state="expanded",
)

# Inject cyberpunk CSS
CyberCSS.inject()

# Define pages using st.navigation (modern Streamlit API)
home_page = st.Page("pages/home.py", title="Home", icon="🏠", default=True)
graph_page = st.Page("pages/graph.py", title="Graph Algorithms", icon="🕸️")
search_page = st.Page("pages/search.py", title="Searching", icon="🔍")
sort_page = st.Page("pages/sort.py", title="Sorting", icon="📊")
dp_page = st.Page("pages/dp.py", title="Dynamic Programming", icon="🧩")
greedy_page = st.Page("pages/greedy.py", title="Greedy Algorithms", icon="💎")
backtrack_page = st.Page("pages/backtrack.py", title="Backtracking", icon="🌲")
ada_page = st.Page("pages/ada.py", title="ADA Theory", icon="📚")
math_page = st.Page("pages/math.py", title="Math Tools", icon="🔢")
bench_page = st.Page("pages/benchmark.py", title="Benchmark Suite", icon="⏱️")
compare_page = st.Page("pages/compare.py", title="Compare All", icon="⚖️")

pages = [
    home_page,
    graph_page,
    search_page,
    sort_page,
    dp_page,
    greedy_page,
    backtrack_page,
    ada_page,
    math_page,
    bench_page,
    compare_page,
]

# Sidebar branding
sidebar_branding()

# Navigation
pg = st.navigation(pages)
pg.run()

# Footer
footer()

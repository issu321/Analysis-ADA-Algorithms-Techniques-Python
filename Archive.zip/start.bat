@echo off
title USSU Algorithm Analyzer v4.0
echo.
echo  USSU Algorithm Analyzer v4.0 Ultra Pro Max
echo  Starting Streamlit Server...
echo.

:: Try venv first, fallback to python -m streamlit
if exist "venv\Scripts\streamlit.exe" (
    venv\Scripts\streamlit.exe run app.py --server.port 8501
) else if exist "venv\Scripts\python.exe" (
    venv\Scripts\python.exe -m streamlit run app.py --server.port 8501
) else (
    python -m streamlit run app.py --server.port 8501
)

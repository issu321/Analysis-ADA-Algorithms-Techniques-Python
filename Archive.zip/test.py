#!/usr/bin/env python3
"""
USSU Algorithm Analyzer v4.0 - Smoke Test
Validates all imports and runs basic algorithm tests.
"""
import sys
import os

# Add project root to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

print("=" * 60)
print("  USSU ALGORITHM ANALYZER v4.0 - SMOKE TEST")
print("  github.com/issu321 | Ussu")
print("=" * 60)

errors = []

# Test 1: Core imports
print("\n[1/8] Testing core utilities...")
try:
    from utils.core import Graph, Colors, profile_algorithm
    try:
        from utils.ui import page_header, algo_card, metric_row
        from utils.viz import plot_graph_cyber, plot_sorting_step, plot_benchmark_bar
        print("  ✅ Core utilities OK (with Streamlit)")
    except ImportError as e:
        print(f"  ⚠️  Core utilities OK (Streamlit components skipped: {e})")
except Exception as e:
    errors.append(f"Core: {e}")
    print(f"  ❌ Core failed: {e}")

# Test 2: Searching
print("\n[2/8] Testing searching algorithms...")
try:
    from algorithms.search import SearchingAlgorithms
    s = SearchingAlgorithms()
    arr = [1, 3, 5, 7, 9, 11, 13]
    r = s.binary_search_iterative(arr, 7)
    assert r['found'] and r['index'] == 3
    print(f"  ✅ Binary Search OK (found at index {r['index']})")
except Exception as e:
    errors.append(f"Search: {e}")
    print(f"  ❌ Search failed: {e}")

# Test 3: Sorting
print("\n[3/8] Testing sorting algorithms...")
try:
    from algorithms.sort import SortingAlgorithms
    s = SortingAlgorithms()
    arr = [64, 34, 25, 12, 22, 11, 90]
    r = s.merge_sort(arr)
    assert r['sorted'] == sorted(arr)
    print(f"  ✅ Merge Sort OK ({len(r['sorted'])} elements)")
except Exception as e:
    errors.append(f"Sort: {e}")
    print(f"  ❌ Sort failed: {e}")

# Test 4: Graph
print("\n[4/8] Testing graph algorithms...")
try:
    from algorithms.graph import GraphAlgorithms
    from utils.core import Graph
    g = Graph.from_random(5, 0.4, weighted=True)
    ga = GraphAlgorithms()
    r = ga.bfs(g, 0)
    assert len(r['traversal']) > 0
    print(f"  ✅ BFS OK (visited {len(r['traversal'])} nodes)")
except Exception as e:
    errors.append(f"Graph: {e}")
    print(f"  ❌ Graph failed: {e}")

# Test 5: DP
print("\n[5/8] Testing dynamic programming...")
try:
    from algorithms.dp import DynamicProgramming
    dp = DynamicProgramming()
    r = dp.knapsack_01([2, 3, 4, 5], [3, 4, 5, 6], 5)
    assert r['max_value'] > 0
    print(f"  ✅ Knapsack OK (max value: {r['max_value']})")
except Exception as e:
    errors.append(f"DP: {e}")
    print(f"  ❌ DP failed: {e}")

# Test 6: Greedy
print("\n[6/8] Testing greedy algorithms...")
try:
    from algorithms.greedy import GreedyAlgorithms
    g = GreedyAlgorithms()
    acts = [(1, 4, 'A1'), (3, 5, 'A2'), (0, 6, 'A3'), (5, 7, 'A4')]
    r = g.activity_selection(acts)
    assert r['count'] > 0
    print(f"  ✅ Activity Selection OK ({r['count']} activities)")
except Exception as e:
    errors.append(f"Greedy: {e}")
    print(f"  ❌ Greedy failed: {e}")

# Test 7: Backtracking
print("\n[7/8] Testing backtracking...")
try:
    from algorithms.backtrack import BacktrackingAlgorithms
    bt = BacktrackingAlgorithms()
    r = bt.n_queens(4)
    assert r['solutions_found'] > 0
    print(f"  ✅ N-Queens OK ({r['solutions_found']} solutions)")
except Exception as e:
    errors.append(f"Backtrack: {e}")
    print(f"  ❌ Backtrack failed: {e}")

# Test 8: Math & ADA
print("\n[8/8] Testing math tools and ADA theory...")
try:
    from algorithms.math_tools import MathTools
    from algorithms.ada import ADATools
    m = MathTools()
    r = m.gcd(48, 18)
    assert r['gcd'] == 6
    ada = ADATools()
    ref = ada.big_o_reference()
    assert len(ref) > 0
    print(f"  ✅ Math & ADA OK (GCD={r['gcd']}, {len(ref)} complexity classes)")
except Exception as e:
    errors.append(f"Math/ADA: {e}")
    print(f"  ❌ Math/ADA failed: {e}")

# Summary
print("\n" + "=" * 60)
if not errors:
    print("  ✅ ALL TESTS PASSED - Project is ready!")
else:
    print(f"  ❌ {len(errors)} TEST(S) FAILED")
    for err in errors:
        print(f"     - {err}")
print("=" * 60)

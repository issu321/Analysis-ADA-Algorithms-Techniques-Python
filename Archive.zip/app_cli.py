#!/usr/bin/env python3
"""
================================================================================
  USSU'S ULTRA PRO MAX ALGORITHM ANALYZER v4.0 - TERMINAL EDITION
  Complete CLI for Kali Linux / Windows Terminal users

  Switch case menu dispatch | Voice greeting | Full algorithm suite
  Author: Ussu (github.com/issu321)
================================================================================
"""

import os
import sys
import time
import random
import platform
import socket

# Add project root to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from utils.core import Graph, profile_algorithm
from algorithms.search import SearchingAlgorithms
from algorithms.sort import SortingAlgorithms
from algorithms.graph import GraphAlgorithms
from algorithms.dp import DynamicProgramming
from algorithms.greedy import GreedyAlgorithms
from algorithms.backtrack import BacktrackingAlgorithms
from algorithms.math_tools import MathTools
from algorithms.ada import ADATools
from algorithms.benchmark import BenchmarkSuite


class Colors:
    END = "\033[0m"
    CYAN = "\033[36m"
    BRIGHT_CYAN = "\033[96m"
    GREEN = "\033[32m"
    RED = "\033[31m"
    YELLOW = "\033[33m"
    GRAY = "\033[90m"


def find_free_port(start=8501, max_port=9000):
    """Find an available TCP port starting from `start`."""
    for port in range(start, max_port):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            if s.connect_ex(("localhost", port)) != 0:
                return port
    raise RuntimeError(f"No free ports found between {start} and {max_port}")


def clear():
    os.system("clear" if os.name != "nt" else "cls")


def print_banner():
    c = Colors
    banner = f"""
{c.CYAN}
    ██╗   ██╗███████╗███████╗██╗   ██╗    █████╗ ██╗      ██████╗  ██████╗ 
    ██║   ██║██╔════╝██╔════╝██║   ██║   ██╔══██╗██║     ██╔═══██╗██╔════╝ 
    ██║   ██║███████╗███████╗██║   ██║   ███████║██║     ██║   ██║██║  ███╗
    ██║   ██║╚════██║╚════██║██║   ██║   ██╔══██║██║     ██║   ██║██║   ██║
    ╚██████╔╝███████║███████║╚██████╔╝   ██║  ██║███████╗╚██████╔╝╚██████╔╝
     ╚═════╝ ╚══════╝╚══════╝ ╚═════╝    ╚═╝  ╚═╝╚══════╝ ╚═════╝  ╚═════╝ 
{c.END}
{c.BRIGHT_CYAN}
         ╔═══════════════════════════════════════════════════════════════╗
         ║     USSU'S ULTRA PRO MAX ALGORITHM ANALYZER v4.0              ║
         ║     Terminal Edition | Kali Linux | Windows 11 | Python 3.13  ║
         ║     github.com/issu321                                        ║
         ╚═══════════════════════════════════════════════════════════════╝
{c.END}
{c.GRAY}
         [ SYSTEM: {platform.system()} {platform.release()} ]
         [ PYTHON: {platform.python_version()} ]
{c.END}
    """
    print(banner)


def print_menu():
    c = Colors
    menu = f"""
{c.CYAN}╔══════════════════════════════════════════════════════════════════════╗{c.END}
{c.CYAN}║{c.END} {c.BRIGHT_CYAN}ALGORITHM ANALYZER COMMAND CENTER v4.0{c.END}                              {c.CYAN}║{c.END}
{c.CYAN}╠══════════════════════════════════════════════════════════════════════╣{c.END}
{c.CYAN}║{c.END} {c.GREEN}[1]{c.END}  Graph Algorithms      {c.GRAY}- BFS, DFS, Dijkstra, MST, SCC{c.END}           {c.CYAN}║{c.END}
{c.CYAN}║{c.END} {c.GREEN}[2]{c.END}  Searching             {c.GRAY}- Linear, Binary, Jump, etc.{c.END}             {c.CYAN}║{c.END}
{c.CYAN}║{c.END} {c.GREEN}[3]{c.END}  Sorting               {c.GRAY}- Bubble, Merge, Quick, Heap, etc.{c.END}       {c.CYAN}║{c.END}
{c.CYAN}║{c.END} {c.GREEN}[4]{c.END}  Dynamic Programming   {c.GRAY}- Knapsack, LCS, Edit Distance{c.END}          {c.CYAN}║{c.END}
{c.CYAN}║{c.END} {c.GREEN}[5]{c.END}  Greedy Algorithms     {c.GRAY}- Activity Selection, Huffman{c.END}           {c.CYAN}║{c.END}
{c.CYAN}║{c.END} {c.GREEN}[6]{c.END}  Backtracking          {c.GRAY}- N-Queens, Sudoku, Hamiltonian{c.END}       {c.CYAN}║{c.END}
{c.CYAN}║{c.END} {c.GREEN}[7]{c.END}  Math Tools            {c.GRAY}- GCD, Primes, Matrix, Power{c.END}            {c.CYAN}║{c.END}
{c.CYAN}║{c.END} {c.GREEN}[8]{c.END}  ADA Theory            {c.GRAY}- Master Theorem, NP, Amortized{c.END}       {c.CYAN}║{c.END}
{c.CYAN}║{c.END} {c.GREEN}[9]{c.END}  Benchmark Suite       {c.GRAY}- Speed profiling & comparison{c.END}        {c.CYAN}║{c.END}
{c.CYAN}║{c.END} {c.GREEN}[10]{c.END} Compare All           {c.GRAY}- Head-to-head across categories{c.END}      {c.CYAN}║{c.END}
{c.CYAN}║{c.END} {c.RED}[Q]{c.END}  Quit                  {c.GRAY}- Exit application{c.END}                    {c.CYAN}║{c.END}
{c.CYAN}╚══════════════════════════════════════════════════════════════════════╝{c.END}
    """
    print(menu)


def graph_menu():
    c = Colors
    print(f"\n{c.CYAN}[GRAPH ALGORITHMS]{c.END}")
    print(f"{c.GREEN}[1]{c.END} Create Random Graph")
    print(f"{c.GREEN}[2]{c.END} BFS Traversal")
    print(f"{c.GREEN}[3]{c.END} DFS Traversal")
    print(f"{c.GREEN}[4]{c.END} Dijkstra Shortest Path")
    print(f"{c.GREEN}[5]{c.END} Bellman-Ford")
    print(f"{c.GREEN}[6]{c.END} Floyd-Warshall")
    print(f"{c.GREEN}[7]{c.END} Prim MST")
    print(f"{c.GREEN}[8]{c.END} Kruskal MST")
    print(f"{c.GREEN}[9]{c.END} Topological Sort")
    print(f"{c.GREEN}[10]{c.END} Kosaraju SCC")
    print(f"{c.GREEN}[B]{c.END} Back")

    g = None
    ga = GraphAlgorithms()

    while True:
        choice = input(f"{c.YELLOW}Select: {c.END}").strip().upper()

        if choice == "1":
            n = int(input("Vertices: ") or "5")
            p = float(input("Edge prob (0-1): ") or "0.3")
            directed = input("Directed? (y/n): ").lower() == "y"
            weighted = input("Weighted? (y/n): ").lower() == "y"
            g = Graph.from_random(n, p, directed, weighted)
            print(
                f"{c.GREEN}[+] Graph created: {len(g.vertices)}V {g.edge_count}E{c.END}"
            )
        elif choice == "B":
            break
        elif g is None:
            print(f"{c.RED}[!] Create a graph first (Option 1){c.END}")
            continue
        elif choice == "2":
            start = int(input("Start: ") or "0")
            result = ga.bfs(g, start)
            print(
                f"{c.GREEN}Traversal: {' → '.join(map(str, result['traversal']))}{c.END}"
            )
        elif choice == "3":
            start = int(input("Start: ") or "0")
            result = ga.dfs_iterative(g, start)
            print(
                f"{c.GREEN}Traversal: {' → '.join(map(str, result['traversal']))}{c.END}"
            )
        elif choice == "4":
            start = int(input("Start: ") or "0")
            target = int(input("Target: ") or str(max(g.vertices)))
            result = ga.dijkstra(g, start, target)
            print(f"{c.GREEN}Distance: {result['distances'].get(target, '∞')}{c.END}")
        elif choice == "5":
            start = int(input("Start: ") or "0")
            result = ga.bellman_ford(g, start)
            print(f"{c.GREEN}Complete{c.END}")
        elif choice == "6":
            result = ga.floyd_warshall(g)
            print(f"{c.GREEN}All-pairs complete{c.END}")
        elif choice == "7":
            result = ga.prim_mst(g)
            print(f"{c.GREEN}MST Weight: {result.get('total_weight', 'N/A')}{c.END}")
        elif choice == "8":
            result = ga.kruskal_mst(g)
            print(f"{c.GREEN}MST Weight: {result.get('total_weight', 'N/A')}{c.END}")
        elif choice == "9":
            result = ga.topological_sort(g)
            print(
                f"{c.GREEN}Order: {' → '.join(map(str, result['topological_order']))}{c.END}"
            )
        elif choice == "10":
            result = ga.kosaraju_scc(g)
            print(f"{c.GREEN}SCCs: {result['count']}{c.END}")


def search_menu():
    c = Colors
    print(f"\n{c.CYAN}[SEARCHING ALGORITHMS]{c.END}")
    searcher = SearchingAlgorithms()

    arr_str = input("Enter sorted numbers (space separated): ").strip()
    arr = list(map(int, arr_str.split())) if arr_str else [1, 3, 5, 7, 9, 11, 13]
    target = int(input("Target: "))

    print(f"\n{c.GREEN}[1]{c.END} Linear Search")
    print(f"{c.GREEN}[2]{c.END} Binary Search")
    print(f"{c.GREEN}[3]{c.END} Jump Search")
    print(f"{c.GREEN}[4]{c.END} Interpolation Search")
    print(f"{c.GREEN}[5]{c.END} Exponential Search")
    print(f"{c.GREEN}[6]{c.END} Ternary Search")
    print(f"{c.GREEN}[7]{c.END} Fibonacci Search")
    print(f"{c.GREEN}[8]{c.END} Compare All")
    print(f"{c.GREEN}[B]{c.END} Back")

    while True:
        choice = input(f"{c.YELLOW}Select: {c.END}").strip().upper()

        if choice == "B":
            break
        elif choice == "1":
            r = searcher.linear_search(arr, target)
        elif choice == "2":
            r = searcher.binary_search_iterative(arr, target)
        elif choice == "3":
            r = searcher.jump_search(arr, target)
        elif choice == "4":
            r = searcher.interpolation_search(arr, target)
        elif choice == "5":
            r = searcher.exponential_search(arr, target)
        elif choice == "6":
            r = searcher.ternary_search(arr, target)
        elif choice == "7":
            r = searcher.fibonacci_search(arr, target)
        elif choice == "8":
            results = searcher.compare_all(arr, target)
            print(
                f"\n{c.CYAN}{'Algorithm':<<25} {'Time (ms)':<<12} {'Found':<<8} {'Index':<<8}{c.END}"
            )
            for res in results:
                if "error" not in res:
                    print(
                        f"{res['name']:<25} {res['time_ms']:<12.6f} {'Yes' if res['found'] else 'No':<<8} {res['index']:<8}"
                    )
            continue
        else:
            continue

        status = (
            f"{c.GREEN}FOUND at {r['index']}{c.END}"
            if r["found"]
            else f"{c.RED}NOT FOUND{c.END}"
        )
        print(f"\n{c.CYAN}{r['algorithm']}{c.END}")
        print(f"  Status: {status}")
        print(
            f"  Time: {r['execution_time_ms']:.4f}ms | Comp: {r['comparisons']} | Access: {r['accesses']}"
        )


def sort_menu():
    c = Colors
    print(f"\n{c.CYAN}[SORTING ALGORITHMS]{c.END}")
    sorter = SortingAlgorithms()

    arr_str = input("Enter numbers (space separated): ").strip()
    arr = list(map(int, arr_str.split())) if arr_str else [64, 34, 25, 12, 22, 11, 90]

    print(f"\n{c.GREEN}[1]{c.END} Bubble Sort")
    print(f"{c.GREEN}[2]{c.END} Selection Sort")
    print(f"{c.GREEN}[3]{c.END} Insertion Sort")
    print(f"{c.GREEN}[4]{c.END} Merge Sort")
    print(f"{c.GREEN}[5]{c.END} Quick Sort")
    print(f"{c.GREEN}[6]{c.END} Heap Sort")
    print(f"{c.GREEN}[7]{c.END} Shell Sort")
    print(f"{c.GREEN}[8]{c.END} Cocktail Shaker")
    print(f"{c.GREEN}[9]{c.END} Comb Sort")
    print(f"{c.GREEN}[10]{c.END} Counting Sort")
    print(f"{c.GREEN}[11]{c.END} Radix Sort")
    print(f"{c.GREEN}[12]{c.END} Compare All")
    print(f"{c.GREEN}[B]{c.END} Back")

    while True:
        choice = input(f"{c.YELLOW}Select: {c.END}").strip().upper()

        if choice == "B":
            break
        elif choice == "12":
            results = sorter.compare_all(arr)
            print(
                f"\n{c.CYAN}{'Algorithm':<<25} {'Time (ms)':<<12} {'Complexity':<<20}{c.END}"
            )
            for r in results:
                if "error" not in r and r["time_ms"] != float("inf"):
                    print(
                        f"{r['name']:<25} {r['time_ms']:<12.4f} {r['complexity']:<20}"
                    )
            continue

        algo_map = {
            "1": sorter.bubble_sort,
            "2": sorter.selection_sort,
            "3": sorter.insertion_sort,
            "4": sorter.merge_sort,
            "5": sorter.quick_sort,
            "6": sorter.heap_sort,
            "7": sorter.shell_sort,
            "8": sorter.cocktail_shaker_sort,
            "9": sorter.comb_sort,
            "10": sorter.counting_sort,
            "11": sorter.radix_sort,
        }

        if choice in algo_map:
            r = algo_map[choice](arr)
            print(f"\n{c.CYAN}{r['algorithm']}{c.END}")
            print(f"  Sorted: {r['sorted'][:20]}{'...' if len(r['sorted'])>20 else ''}")
            print(
                f"  Time: {r['execution_time_ms']:.4f}ms | Comp: {r['comparisons']} | Swaps: {r['swaps']}"
            )


def dp_menu():
    c = Colors
    print(f"\n{c.CYAN}[DYNAMIC PROGRAMMING]{c.END}")
    dp = DynamicProgramming()

    print(f"{c.GREEN}[1]{c.END} 0/1 Knapsack")
    print(f"{c.GREEN}[2]{c.END} LCS")
    print(f"{c.GREEN}[3]{c.END} Edit Distance")
    print(f"{c.GREEN}[4]{c.END} Matrix Chain")
    print(f"{c.GREEN}[5]{c.END} Coin Change")
    print(f"{c.GREEN}[B]{c.END} Back")

    while True:
        choice = input(f"{c.YELLOW}Select: {c.END}").strip().upper()
        if choice == "B":
            break
        elif choice == "1":
            w = list(map(int, input("Weights: ").split()))
            v = list(map(int, input("Values: ").split()))
            cap = int(input("Capacity: "))
            r = dp.knapsack_01(w, v, cap)
            print(
                f"{c.GREEN}Max Value: {r['max_value']} | Items: {r['selected_items']}{c.END}"
            )
        elif choice == "2":
            s1 = input("String 1: ")
            s2 = input("String 2: ")
            r = dp.lcs(s1, s2)
            print(f"{c.GREEN}LCS: '{r['subsequence']}' (length {r['length']}){c.END}")
        elif choice == "3":
            s1 = input("Source: ")
            s2 = input("Target: ")
            r = dp.edit_distance(s1, s2)
            print(f"{c.GREEN}Distance: {r['distance']}{c.END}")
        elif choice == "4":
            dims = list(map(int, input("Dimensions (space): ").split()))
            r = dp.matrix_chain_order(dims)
            print(
                f"{c.GREEN}Min ops: {r['min_multiplications']} | {r['optimal_parenthesization']}{c.END}"
            )
        elif choice == "5":
            coins = list(map(int, input("Coins: ").split()))
            amt = int(input("Amount: "))
            r = dp.coin_change_min(coins, amt)
            print(
                f"{c.GREEN}Min coins: {r['min_coins']} | Used: {r['coins_used']}{c.END}"
            )


def greedy_menu():
    c = Colors
    print(f"\n{c.CYAN}[GREEDY ALGORITHMS]{c.END}")
    greedy = GreedyAlgorithms()

    print(f"{c.GREEN}[1]{c.END} Activity Selection")
    print(f"{c.GREEN}[2]{c.END} Fractional Knapsack")
    print(f"{c.GREEN}[3]{c.END} Huffman Coding")
    print(f"{c.GREEN}[4]{c.END} Job Sequencing")
    print(f"{c.GREEN}[B]{c.END} Back")

    while True:
        choice = input(f"{c.YELLOW}Select: {c.END}").strip().upper()
        if choice == "B":
            break
        elif choice == "1":
            n = int(input("Activities: ") or "4")
            acts = []
            for i in range(n):
                s = int(input(f"  A{i+1} start: "))
                f = int(input(f"  A{i+1} finish: "))
                acts.append((s, f, f"A{i+1}"))
            r = greedy.activity_selection(acts)
            print(f"{c.GREEN}Selected: {[a[2] for a in r['selected']]}{c.END}")
        elif choice == "2":
            w = list(map(int, input("Weights: ").split()))
            v = list(map(int, input("Values: ").split()))
            cap = int(input("Capacity: "))
            r = greedy.fractional_knapsack(w, v, cap)
            print(f"{c.GREEN}Max Value: {r['max_value']:.2f}{c.END}")
        elif choice == "3":
            text = input("Text: ")
            from collections import Counter

            r = greedy.huffman_coding(dict(Counter(text)))
            print(f"{c.GREEN}Codes: {r['codes']}{c.END}")
        elif choice == "4":
            n = int(input("Jobs: ") or "3")
            jobs = []
            for i in range(n):
                d = int(input(f"  J{i+1} deadline: "))
                p = int(input(f"  J{i+1} profit: "))
                jobs.append((f"J{i+1}", d, p))
            r = greedy.job_sequencing(jobs)
            print(
                f"{c.GREEN}Profit: {r['total_profit']} | {r['scheduled_jobs']}{c.END}"
            )


def backtrack_menu():
    c = Colors
    print(f"\n{c.CYAN}[BACKTRACKING]{c.END}")
    bt = BacktrackingAlgorithms()

    print(f"{c.GREEN}[1]{c.END} N-Queens")
    print(f"{c.GREEN}[2]{c.END} Sudoku")
    print(f"{c.GREEN}[3]{c.END} Subset Sum")
    print(f"{c.GREEN}[4]{c.END} Graph Coloring")
    print(f"{c.GREEN}[B]{c.END} Back")

    while True:
        choice = input(f"{c.YELLOW}Select: {c.END}").strip().upper()
        if choice == "B":
            break
        elif choice == "1":
            n = int(input("Board size: ") or "8")
            r = bt.n_queens(n)
            print(f"{c.GREEN}Solutions: {r['solutions_found']}{c.END}")
        elif choice == "2":
            print("Enter 9 rows, space separated (0 for empty):")
            grid = []
            for i in range(9):
                grid.append(list(map(int, input(f"Row {i+1}: ").split())))
            r = bt.sudoku_solver(grid)
            print(f"{c.GREEN}Solved: {r['solved']}{c.END}")
        elif choice == "3":
            arr = list(map(int, input("Array: ").split()))
            target = int(input("Target: "))
            r = bt.subset_sum(arr, target)
            print(f"{c.GREEN}Subsets: {r['subsets']}{c.END}")
        elif choice == "4":
            n = int(input("Nodes: ") or "4")
            m = int(input("Colors: ") or "3")
            print("Enter adjacency matrix:")
            adj = []
            for i in range(n):
                adj.append(list(map(int, input(f"Row {i}: ").split())))
            r = bt.graph_coloring(adj, m)
            print(f"{c.GREEN}Colorable: {r['possible']} | {r['coloring']}{c.END}")


def math_menu():
    c = Colors
    print(f"\n{c.CYAN}[MATH TOOLS]{c.END}")
    mt = MathTools()

    print(f"{c.GREEN}[1]{c.END} Factorial")
    print(f"{c.GREEN}[2]{c.END} Fibonacci")
    print(f"{c.GREEN}[3]{c.END} GCD")
    print(f"{c.GREEN}[4]{c.END} Extended GCD")
    print(f"{c.GREEN}[5]{c.END} Fast Power")
    print(f"{c.GREEN}[6]{c.END} Primality Test")
    print(f"{c.GREEN}[7]{c.END} Sieve")
    print(f"{c.GREEN}[8]{c.END} Matrix Multiply")
    print(f"{c.GREEN}[B]{c.END} Back")

    while True:
        choice = input(f"{c.YELLOW}Select: {c.END}").strip().upper()
        if choice == "B":
            break
        elif choice == "1":
            n = int(input("n: "))
            r = mt.factorial(n)
            print(f"{c.GREEN}{n}! = {r['result']}{c.END}")
        elif choice == "2":
            n = int(input("n: "))
            method = input("Method (iterative/memoization/recursive): ") or "iterative"
            r = mt.fibonacci(n, method)
            print(f"{c.GREEN}Fib: {r['sequence']}{c.END}")
        elif choice == "3":
            a = int(input("a: "))
            b = int(input("b: "))
            r = mt.gcd(a, b)
            print(f"{c.GREEN}GCD({a},{b}) = {r['gcd']}{c.END}")
        elif choice == "4":
            a = int(input("a: "))
            b = int(input("b: "))
            r = mt.extended_gcd(a, b)
            print(f"{c.GREEN}GCD={r['gcd']} | x={r['x']} y={r['y']}{c.END}")
        elif choice == "5":
            b = float(input("Base: "))
            e = int(input("Exp: "))
            r = mt.fast_exponentiation(b, e)
            print(f"{c.GREEN}{b}^{e} = {r['result']}{c.END}")
        elif choice == "6":
            n = int(input("n: "))
            r = mt.is_prime(n)
            print(f"{c.GREEN}{n} is {'prime' if r['is_prime'] else 'not prime'}{c.END}")
        elif choice == "7":
            n = int(input("Up to: "))
            r = mt.sieve_eratosthenes(n)
            print(f"{c.GREEN}Primes: {r['primes']}{c.END}")
        elif choice == "8":
            print("Matrix A (2x2):")
            A = [list(map(float, input().split())) for _ in range(2)]
            print("Matrix B (2x2):")
            B = [list(map(float, input().split())) for _ in range(2)]
            r = mt.matrix_multiply(A, B)
            print(f"{c.GREEN}Result: {r['result']}{c.END}")


def ada_menu():
    c = Colors
    print(f"\n{c.CYAN}[ADA THEORY]{c.END}")
    ada = ADATools()

    print(f"{c.GREEN}[1]{c.END} Big-O Reference")
    print(f"{c.GREEN}[2]{c.END} Master Theorem")
    print(f"{c.GREEN}[3]{c.END} Amortized Analysis (Dynamic Array)")
    print(f"{c.GREEN}[4]{c.END} NP-Completeness Reference")
    print(f"{c.GREEN}[5]{c.END} Paradigm Comparison")
    print(f"{c.GREEN}[B]{c.END} Back")

    while True:
        choice = input(f"{c.YELLOW}Select: {c.END}").strip().upper()
        if choice == "B":
            break
        elif choice == "1":
            ref = ada.big_o_reference()
            print(f"\n{c.CYAN}{'Notation':<<12} {'Name':<<18} {'Example'}{c.END}")
            for item in ref:
                print(f"{item['notation']:<12} {item['name']:<18} {item['example']}")
        elif choice == "2":
            a = float(input("a: "))
            b = float(input("b: "))
            f = input("f(n) [1/n/n^2/n*log(n)]: ")
            r = ada.master_theorem(a, b, f)
            print(f"{c.GREEN}Case {r.case}: {r.solution}{c.END}")
            print(f"Explanation: {r.explanation}")
        elif choice == "3":
            n = int(input("Operations: ") or "20")
            r = ada.amortized_dynamic_array(n)
            print(f"{c.GREEN}Amortized cost: {r['amortized_cost']:.2f} per op{c.END}")
        elif choice == "4":
            np_data = ada.np_completeness_reference()
            for cls in np_data["complexity_classes"]:
                print(f"\n{c.CYAN}{cls['class']}{c.END}: {cls['definition']}")
        elif choice == "5":
            paradigms = ada.paradigm_comparison()
            for p in paradigms:
                print(f"\n{c.CYAN}{p['paradigm']}{c.END}")
                print(f"  Approach: {p['approach']}")
                print(f"  Examples: {', '.join(p['examples'])}")


def benchmark_menu():
    c = Colors
    print(f"\n{c.CYAN}[BENCHMARK SUITE]{c.END}")
    suite = BenchmarkSuite()

    print(f"{c.GREEN}[1]{c.END} Search Benchmark")
    print(f"{c.GREEN}[2]{c.END} Sort Benchmark")
    print(f"{c.GREEN}[3]{c.END} Graph Benchmark")
    print(f"{c.GREEN}[B]{c.END} Back")

    while True:
        choice = input(f"{c.YELLOW}Select: {c.END}").strip().upper()
        if choice == "B":
            break
        elif choice == "1":
            sizes = [100, 1000, 5000]
            r = suite.benchmark_search(sizes)
            print(
                f"\n{c.CYAN}{'Size':<<10} {'Linear':<<12} {'Binary':<<12} {'Jump':<<12}{c.END}"
            )
            for item in r:
                print(
                    f"{item['size']:<10} {item['times']['Linear Search']:<12.6f} {item['times']['Binary Search']:<12.6f} {item['times']['Jump Search']:<12.6f}"
                )
        elif choice == "2":
            sizes = [100, 500, 1000]
            r = suite.benchmark_sort(sizes)
            print(
                f"\n{c.CYAN}{'Size':<<10} {'Merge':<<12} {'Quick':<<12} {'Heap':<<12}{c.END}"
            )
            for item in r:
                print(
                    f"{item['size']:<10} {item['times']['Merge']:<12.4f} {item['times']['Quick']:<12.4f} {item['times']['Heap']:<12.4f}"
                )
        elif choice == "3":
            sizes = [10, 20, 50]
            r = suite.benchmark_graph(sizes)
            print(
                f"\n{c.CYAN}{'Size':<<10} {'BFS':<<12} {'DFS':<<12} {'Dijkstra':<<12}{c.END}"
            )
            for item in r:
                print(
                    f"{item['size']:<10} {item['bfs']:<12.4f} {item['dfs']:<12.4f} {item['dijkstra']:<12.4f}"
                )


def main():
    c = Colors
    clear()
    print_banner()
    time.sleep(0.5)

    # Mode selection
    print(f"{c.CYAN}Select Mode:{c.END}")
    print(f"{c.GREEN}[1]{c.END} Terminal Mode (this CLI)")
    print(f"{c.GREEN}[2]{c.END} Launch Streamlit Web UI")
    print(f"{c.GREEN}[Q]{c.END} Quit")

    mode = input(f"{c.YELLOW}Mode: {c.END}").strip().upper()

    if mode == "2":
        print(f"{c.CYAN}[*] Launching Streamlit...{c.END}")
        try:
            port = find_free_port()
            print(f"{c.GREEN}[+] Starting on port {port}{c.END}")
            os.system(f"python3 -m streamlit run app.py --server.port {port}")
        except RuntimeError as e:
            print(f"{c.RED}[!] Error: {e}{c.END}")
        return
    elif mode == "Q":
        print(f"{c.CYAN}[+] Goodbye!{c.END}")
        return

    # Main CLI loop
    while True:
        clear()
        print_banner()
        print_menu()

        choice = (
            input(f"{c.CYAN}[USSU v4.0]{c.END} {c.YELLOW}Enter choice: {c.END}")
            .strip()
            .upper()
        )

        dispatch = {
            "1": graph_menu,
            "2": search_menu,
            "3": sort_menu,
            "4": dp_menu,
            "5": greedy_menu,
            "6": backtrack_menu,
            "7": math_menu,
            "8": ada_menu,
            "9": benchmark_menu,
            "10": lambda: print("Use Streamlit UI for full comparison"),
            "Q": lambda: sys.exit(0),
        }

        action = dispatch.get(choice)
        if action:
            try:
                action()
            except Exception as e:
                print(f"{c.RED}[!] Error: {e}{c.END}")
            input(f"\n{c.GRAY}Press Enter to continue...{c.END}")
        else:
            print(f"{c.RED}[!] Invalid choice{c.END}")
            time.sleep(0.5)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print(f"\n{c.CYAN}[+] Interrupted by user.{c.END}")
        sys.exit(0)
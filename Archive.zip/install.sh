#!/bin/bash

# ============================================================
#  USSU ALGORITHM ANALYZER v4.0 - TERMINAL CLI STARTUP
#  Developed by issu321
#  GitHub:
#  https://github.com/issu321/Analysis-ADA-Algorithms-Techniques-Python
# ============================================================

set -e

# =========================
# COLORS
# =========================
GREEN='\033[0;32m'
BLUE='\033[0;34m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
MAGENTA='\033[0;35m'
NC='\033[0m'

clear

echo ""
echo "╔══════════════════════════════════════════════════════════════╗"
echo "║                                                              ║"
echo "║         🧠 USSU ALGORITHM ANALYZER v4.0 🧠                  ║"
echo "║                                                              ║"
echo "║                TERMINAL CLI STARTUP MODE                    ║"
echo "║                                                              ║"
echo "║                  Developed by issu321                       ║"
echo "║                                                              ║"
echo "╚══════════════════════════════════════════════════════════════╝"
echo ""

echo -e "${MAGENTA}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "📚 ADA Algorithm Analysis & Visualization"
echo -e "⚡ Sorting, Searching & Graph Algorithms"
echo -e "📈 Complexity & Big-O Demonstrations"
echo -e "🖥️  Optimized CLI Experience for Linux"
echo -e "${MAGENTA}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo ""

# ============================================================
# VENV CONFIRMATION
# ============================================================

echo -e "${YELLOW}[IMPORTANT NOTICE]${NC}"
echo ""
echo "Python Virtual Environment (venv) is RECOMMENDED."
echo ""
echo "Before continuing:"
echo " • Create a Python virtual environment"
echo " • Activate the venv"
echo ""
echo -e "Type ${GREEN}yes${NC}  -> Continue startup"
echo -e "Type ${RED}exit${NC} -> Stop execution"
echo ""

read -p "Enter choice (yes/exit): " USER_INPUT

# ============================================================
# EXIT SAFELY
# ============================================================

if [ "$USER_INPUT" = "exit" ]; then
    echo ""
    echo -e "${RED}[EXIT]${NC} Startup terminated by user."
    echo ""
    echo "Recommended setup:"
    echo "--------------------------------------------------"
    echo "python3 -m venv venv"
    echo "source venv/bin/activate"
    echo "bash start.sh"
    echo "--------------------------------------------------"
    echo ""
    exit 1
fi

# ============================================================
# INVALID INPUT
# ============================================================

if [ "$USER_INPUT" != "yes" ]; then
    echo ""
    echo -e "${RED}[ERROR]${NC} Invalid input detected."
    echo "Run again and type only: yes or exit"
    echo ""
    exit 1
fi

echo ""
echo -e "${GREEN}[OK]${NC} Initializing USSU Algorithm Analyzer..."
echo ""

# ============================================================
# PYTHON VERSION CHECK
# ============================================================

PYTHON_VERSION=$(python3 -c 'import sys; print(sys.version_info.major, sys.version_info.minor)' | tr ' ' '.')

echo -e "${GREEN}[OK]${NC} Python $PYTHON_VERSION detected"
echo ""

# ============================================================
# STARTUP INITIALIZATION
# ============================================================

echo -e "${BLUE}[1/3]${NC} Loading ADA modules..."
sleep 1

echo -e "${BLUE}[2/3]${NC} Preparing algorithm engine..."
sleep 1

echo -e "${BLUE}[3/3]${NC} Launching terminal interface..."
sleep 1

echo ""
echo "╔══════════════════════════════════════════════════════════════╗"
echo "║                                                              ║"
echo "║              🚀 SYSTEM READY FOR EXECUTION 🚀               ║"
echo "║                                                              ║"
echo "║          USSU Algorithm Analyzer v4.0 Initialized           ║"
echo "║                                                              ║"
echo "╚══════════════════════════════════════════════════════════════╝"
echo ""

echo -e "${CYAN}🖥️  Launching Terminal CLI Mode...${NC}"
echo ""
python3 app_cli.py

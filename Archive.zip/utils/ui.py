"""
USSU Algorithm Analyzer v4.0 - Streamlit UI Components
Cyberpunk-themed custom components for immersive UX.
"""
import streamlit as st
from typing import Dict, List, Any, Optional


def sidebar_branding():
    """Render sidebar branding and navigation info"""
    with st.sidebar:
        st.html("""
        <div style="text-align:center; margin-bottom:20px;">
            <h1 style="font-family:'Orbitron',sans-serif; color:#22d3ee; font-size:28px; margin:0;">
                USSU
            </h1>
            <p style="color:#64748b; font-size:12px; margin-top:4px;">
                ALGORITHM ANALYZER v4.0
            </p>
            <div style="height:2px; background:linear-gradient(90deg,#06b6d4,#8b5cf6); margin:12px 0;"></div>
            <p style="color:#94a3b8; font-size:11px;">
                by <a href="https://github.com/issu321" target="_blank" style="color:#06b6d4; text-decoration:none;">Ussu</a>
            </p>
        </div>
        """)

        st.html("""
        <div style="background:rgba(30,41,59,0.8); border-radius:10px; padding:12px; margin-bottom:16px;">
            <p style="color:#22d3ee; font-weight:700; font-size:13px; margin-bottom:8px;">⚡ SYSTEM STATUS</p>
            <p style="color:#94a3b8; font-size:11px; margin:2px 0;">Platform: Online</p>
            <p style="color:#94a3b8; font-size:11px; margin:2px 0;">Engine: Python 3.13 Ready</p>
            <p style="color:#94a3b8; font-size:11px; margin:2px 0;">UI: Streamlit Cyberpunk</p>
        </div>
        """)


def page_header(title: str, subtitle: str = ""):
    """Render a cyberpunk page header"""
    subtitle_html = f'<p style="color:#64748b; font-size:16px; margin-top:8px; font-family: Rajdhani,sans-serif;">{subtitle}</p>' if subtitle else ''
    st.html(f"""
    <div style="margin-bottom:24px;">
        <h1 style="font-family:'Orbitron',sans-serif; color:#22d3ee; margin:0; font-size:36px; text-shadow:0 0 15px rgba(34,211,238,0.4);">
            {title}
        </h1>
        {subtitle_html}
        <div style="height:3px; width:120px; background:linear-gradient(90deg,#06b6d4,#8b5cf6); border-radius:2px; margin-top:12px;"></div>
    </div>
    """)


def algo_card(name: str, time_comp: str, space_comp: str, stable: Optional[str] = None, desc: str = ""):
    """Render an algorithm info badge card"""
    if stable == "Yes":
        stable_badge = '<span style="background:#10b981; color:white; padding:2px 8px; border-radius:4px; font-size:11px; margin-left:8px;">STABLE</span>'
    elif stable == "No":
        stable_badge = '<span style="background:#ef4444; color:white; padding:2px 8px; border-radius:4px; font-size:11px; margin-left:8px;">UNSTABLE</span>'
    else:
        stable_badge = ""

    st.html(f"""
    <div style="background:rgba(30,41,59,0.9); border:1px solid #334155; border-radius:12px; padding:16px; margin-bottom:12px; border-left:4px solid #06b6d4;">
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:8px;">
            <h3 style="color:#f8fafc; margin:0; font-size:18px; font-family:'Orbitron',sans-serif;">{name}</h3>
            {stable_badge}
        </div>
        <div style="display:flex; gap:12px; margin-bottom:8px;">
            <span style="background:rgba(6,182,212,0.15); color:#22d3ee; padding:4px 10px; border-radius:6px; font-size:12px; font-weight:600;">⏱ {time_comp}</span>
            <span style="background:rgba(139,92,246,0.15); color:#a78bfa; padding:4px 10px; border-radius:6px; font-size:12px; font-weight:600;">💾 {space_comp}</span>
        </div>
        <p style="color:#94a3b8; font-size:13px; margin:0;">{desc}</p>
    </div>
    """)


def metric_row(metrics: Dict[str, Any], columns: int = 4):
    """Render metric boxes in a row"""
    cols = st.columns(columns)
    colors = ["#06b6d4", "#8b5cf6", "#10b981", "#f59e0b", "#ef4444", "#d946ef"]
    for i, (label, value) in enumerate(metrics.items()):
        if i >= columns:
            break
        with cols[i]:
            color = colors[i % len(colors)]
            st.html(f"""
            <div style="background:rgba(30,41,59,0.95); border:1px solid {color}; border-radius:10px; padding:12px; text-align:center; box-shadow:0 0 10px {color}33;">
                <p style="color:{color}; font-size:12px; font-weight:700; margin:0; letter-spacing:1px;">{label.upper()}</p>
                <p style="color:#f8fafc; font-size:22px; font-weight:700; margin:4px 0; font-family:'Orbitron',sans-serif;">{value}</p>
            </div>
            """)


def section_divider(title: str):
    st.html(f"""
    <div style="margin:24px 0 16px 0;">
        <h3 style="color:#a78bfa; font-family:'Orbitron',sans-serif; font-size:20px; margin:0;">
            ▸ {title}
        </h3>
        <div style="height:1px; background:linear-gradient(90deg,#8b5cf6,transparent); margin-top:6px;"></div>
    </div>
    """)


def code_block(code: str, language: str = "python"):
    st.html(f"""
    <div style="background:#020617; border-left:3px solid #06b6d4; border-radius:0 8px 8px 0; padding:12px; margin:8px 0; overflow-x:auto;">
        <pre style="color:#e2e8f0; font-family:'Fira Code',monospace; font-size:13px; margin:0;"><code>{code}</code></pre>
    </div>
    """)


def result_box(status: str, message: str):
    color = "#10b981" if status == "success" else "#ef4444" if status == "error" else "#f59e0b"
    icon = "✓" if status == "success" else "✗" if status == "error" else "⚠"
    st.html(f"""
    <div style="background:rgba(30,41,59,0.9); border:1px solid {color}; border-radius:8px; padding:10px 14px; margin:8px 0;">
        <span style="color:{color}; font-weight:700;">{icon} {message}</span>
    </div>
    """)


def theory_box(title: str, content: str, type_: str = "info"):
    border = {"info": "#06b6d4", "warning": "#f59e0b", "danger": "#ef4444", "success": "#10b981"}.get(type_, "#06b6d4")
    st.html(f"""
    <div style="background:rgba(30,41,59,0.8); border-left:4px solid {border}; border-radius:0 10px 10px 0; padding:14px; margin:10px 0;">
        <h4 style="color:{border}; margin:0 0 6px 0; font-size:14px; font-family:'Orbitron',sans-serif;">{title}</h4>
        <p style="color:#cbd5e1; font-size:13px; line-height:1.6; margin:0;">{content}</p>
    </div>
    """)


def footer():
    st.html("""
    <div class="ussu-footer">
        USSU ALGORITHM ANALYZER v4.0 | Built by <a href="https://github.com/issu321" target="_blank" style="color:#06b6d4; text-decoration:none;">Ussu</a> 
        | Kali Linux & Windows 11 Compatible | Python 3.13 Ready
    </div>
    """)
"""
USSU Algorithm Analyzer v4.0 - Visualization Engine
Cyberpunk-styled plots for sorting, graphs, benchmarks, and ADA theory.
"""
import numpy as np
import matplotlib.pyplot as plt
import networkx as nx
from typing import List, Dict, Tuple, Optional, Any
from collections import deque

# Cyberpunk color palette
CP = {
    'bg': '#0f172a',
    'panel': '#1e293b',
    'cyan': '#06b6d4',
    'bright_cyan': '#22d3ee',
    'violet': '#8b5cf6',
    'green': '#10b981',
    'yellow': '#f59e0b',
    'red': '#ef4444',
    'magenta': '#d946ef',
    'white': '#f8fafc',
    'gray': '#94a3b8',
    'grid': '#334155',
}


def _setup_cyber_fig(figsize=(10, 6)):
    fig, ax = plt.subplots(figsize=figsize, facecolor=CP['bg'])
    ax.set_facecolor(CP['bg'])
    ax.tick_params(colors=CP['gray'])
    for spine in ax.spines.values():
        spine.set_color(CP['grid'])
    return fig, ax


def plot_sorting_step(arr: List[int], title: str = "Sorting",
                      compare: Optional[Tuple[int, int]] = None,
                      swap: Optional[Tuple[int, int]] = None,
                      sorted_prefix: int = 0,
                      figsize=(12, 5)):
    """Generate a single sorting step figure"""
    fig, ax = _setup_cyber_fig(figsize)
    n = len(arr)
    colors = [CP['cyan']] * n

    if sorted_prefix > 0:
        for i in range(sorted_prefix):
            colors[i] = CP['green']

    if compare:
        i, j = compare
        colors[i] = CP['yellow']
        colors[j] = CP['yellow']

    if swap:
        i, j = swap
        colors[i] = CP['red']
        colors[j] = CP['red']

    bars = ax.bar(range(n), arr, color=colors, edgecolor=CP['white'], linewidth=0.5)
    ax.set_title(title, color=CP['bright_cyan'], fontsize=16, fontweight='bold', pad=15)
    ax.set_xlabel("Index", color=CP['gray'], fontsize=12)
    ax.set_ylabel("Value", color=CP['gray'], fontsize=12)
    ax.grid(axis='y', color=CP['grid'], linestyle='--', alpha=0.5)

    # Add value labels on bars
    for bar in bars:
        height = bar.get_height()
        ax.annotate(f'{int(height)}',
                    xy=(bar.get_x() + bar.get_width() / 2, height),
                    xytext=(0, 3),
                    textcoords="offset points",
                    ha='center', va='bottom',
                    color=CP['white'], fontsize=8)

    plt.tight_layout()
    return fig


def plot_sorting_frames(steps: List[Dict], interval_ms: int = 200):
    """
    steps: list of dicts with keys: array, compare, swap, sorted_prefix, title
    Returns list of figures (for Streamlit animation via st.empty loop)
    """
    figs = []
    for step in steps:
        fig = plot_sorting_step(
            step['array'],
            title=step.get('title', 'Sorting'),
            compare=step.get('compare'),
            swap=step.get('swap'),
            sorted_prefix=step.get('sorted_prefix', 0)
        )
        figs.append(fig)
    return figs


def plot_graph_cyber(graph, highlight_path: Optional[List[int]] = None,
                     highlight_nodes: Optional[List[int]] = None,
                     title: str = "Graph Visualization", figsize=(10, 8)):
    """Visualize a Graph object with cyberpunk styling"""
    fig, ax = _setup_cyber_fig(figsize)

    G = nx.DiGraph() if graph.directed else nx.Graph()
    for v in graph.vertices:
        G.add_node(v)
    edge_weights = {}
    for u, v, w in graph.edges:
        weight = w if w is not None else 1
        G.add_edge(u, v, weight=weight)
        edge_weights[(u, v)] = weight

    if len(G.nodes) == 0:
        ax.text(0.5, 0.5, "Empty Graph", color=CP['gray'], ha='center', va='center', transform=ax.transAxes)
        plt.tight_layout()
        return fig

    try:
        if len(G.nodes) == 1:
            pos = {list(G.nodes)[0]: (0.5, 0.5)}
        elif len(G.nodes) == 2:
            pos = {list(G.nodes)[0]: (0.2, 0.5), list(G.nodes)[1]: (0.8, 0.5)}
        else:
            pos = nx.spring_layout(G, k=1.5, iterations=50, seed=42)
    except Exception:
        # Fallback for problematic graphs
        pos = nx.circular_layout(G)

    node_colors = []
    for node in G.nodes():
        if highlight_nodes and node in highlight_nodes:
            node_colors.append(CP['yellow'])
        elif highlight_path and node in highlight_path:
            node_colors.append(CP['green'])
        else:
            node_colors.append(CP['cyan'])

    edge_colors = []
    for u, v in G.edges():
        if highlight_path and u in highlight_path and v in highlight_path:
            # Check adjacency in path
            path_set = set(zip(highlight_path, highlight_path[1:]))
            rev_path_set = set((b, a) for a, b in path_set)
            if (u, v) in path_set or (u, v) in rev_path_set:
                edge_colors.append(CP['green'])
            else:
                edge_colors.append(CP['violet'])
        else:
            edge_colors.append(CP['violet'])

    nx.draw_networkx_nodes(G, pos, node_color=node_colors, node_size=1200,
                           edgecolors=CP['white'], linewidths=2, ax=ax)
    nx.draw_networkx_labels(G, pos, font_color=CP['white'], font_size=12,
                            font_weight='bold', ax=ax)
    edge_kwargs = {
        'edge_color': edge_colors,
        'width': 2.5,
        'arrows': graph.directed,
        'arrowsize': 20,
        'alpha': 0.9,
        'ax': ax,
    }
    if graph.directed:
        edge_kwargs['connectionstyle'] = 'arc3,rad=0.1'
    nx.draw_networkx_edges(G, pos, **edge_kwargs)

    if graph.weighted:
        labels = nx.get_edge_attributes(G, 'weight')
        nx.draw_networkx_edge_labels(G, pos, edge_labels=labels,
                                     font_color=CP['yellow'], font_size=10,
                                     font_weight='bold', ax=ax)

    ax.set_title(title, color=CP['bright_cyan'], fontsize=16, fontweight='bold', pad=15)
    plt.axis('off')
    plt.tight_layout()
    return fig


def plot_benchmark_bar(results: List[Dict], title: str = "Benchmark Results", metric: str = "time_ms"):
    """Plot benchmark results as cyberpunk bar chart"""
    fig, ax = _setup_cyber_fig((12, 6))
    names = [r['name'] for r in results]
    values = [r.get(metric, 0) for r in results]

    colors = [CP['cyan'] if v == min(values) else CP['violet'] if v < np.mean(values) else CP['red'] for v in values]
    bars = ax.barh(names, values, color=colors, edgecolor=CP['white'], linewidth=0.5)

    ax.set_xlabel("Time (ms)" if metric == "time_ms" else metric, color=CP['gray'], fontsize=12)
    ax.set_title(title, color=CP['bright_cyan'], fontsize=16, fontweight='bold', pad=15)
    ax.grid(axis='x', color=CP['grid'], linestyle='--', alpha=0.5)

    for bar in bars:
        width = bar.get_width()
        ax.annotate(f'{width:.4f}',
                    xy=(width, bar.get_y() + bar.get_height() / 2),
                    xytext=(5, 0),
                    textcoords="offset points",
                    ha='left', va='center',
                    color=CP['white'], fontsize=9)

    plt.tight_layout()
    return fig


def plot_benchmark_lines(results: List[Dict], x_key: str = "size", y_key: str = "time_ms",
                         title: str = "Scaling Analysis"):
    """Line plot for scaling benchmark"""
    fig, ax = _setup_cyber_fig((12, 6))

    # results is dict of algorithm -> list of {x, y}
    colors = [CP['cyan'], CP['violet'], CP['green'], CP['yellow'], CP['red'], CP['magenta']]

    if isinstance(results, dict):
        for i, (algo, points) in enumerate(results.items()):
            x = [p[x_key] for p in points]
            y = [p[y_key] for p in points]
            ax.plot(x, y, marker='o', color=colors[i % len(colors)], linewidth=2.5,
                    markersize=8, label=algo)
    else:
        # List of dicts with single series
        x = [r[x_key] for r in results]
        y = [r[y_key] for r in results]
        ax.plot(x, y, marker='o', color=CP['cyan'], linewidth=2.5, markersize=8)

    ax.set_xlabel(str(x_key).replace('_', ' ').title(), color=CP['gray'], fontsize=12)
    ax.set_ylabel(str(y_key).replace('_', ' ').title(), color=CP['gray'], fontsize=12)
    ax.set_title(title, color=CP['bright_cyan'], fontsize=16, fontweight='bold', pad=15)
    ax.legend(facecolor=CP['panel'], edgecolor=CP['grid'], labelcolor=CP['gray'])
    ax.grid(color=CP['grid'], linestyle='--', alpha=0.5)
    plt.tight_layout()
    return fig


def plot_complexity_radar():
    """Radar chart comparing complexity classes"""
    fig, ax = _setup_cyber_fig((8, 8))
    # Not a standard radar with matplotlib polar, keep simple
    return fig


def plot_dp_table(table: List[List[Any]], title: str = "DP Table", row_labels=None, col_labels=None):
    """Visualize a DP table as a colored grid"""
    fig, ax = _setup_cyber_fig(figsize=(max(8, len(table[0])*1.2), max(6, len(table)*0.8)))

    # Convert to numeric if possible
    numeric_table = []
    for row in table:
        numeric_row = []
        for val in row:
            if isinstance(val, (int, float)):
                numeric_row.append(float(val))
            else:
                numeric_row.append(0.0)
        numeric_table.append(numeric_row)

    arr = np.array(numeric_table)
    cax = ax.imshow(arr, cmap='viridis', aspect='auto')

    # Add text annotations
    for i in range(len(table)):
        for j in range(len(table[0])):
            text = str(table[i][j])
            ax.text(j, i, text, ha='center', va='center', color='white', fontsize=10, fontweight='bold')

    if row_labels:
        ax.set_yticks(range(len(row_labels)))
        ax.set_yticklabels(row_labels, color=CP['gray'])
    if col_labels:
        ax.set_xticks(range(len(col_labels)))
        ax.set_xticklabels(col_labels, color=CP['gray'])

    ax.set_title(title, color=CP['bright_cyan'], fontsize=16, fontweight='bold', pad=15)
    plt.colorbar(cax, ax=ax, fraction=0.046, pad=0.04)
    plt.tight_layout()
    return fig


def plot_recursion_tree(levels: List[List[str]], title: str = "Recursion Tree"):
    """Visualize a recursion tree structure"""
    fig, ax = _setup_cyber_fig(figsize=(14, 8))

    # Simple tree layout
    max_width = max(len(level) for level in levels)
    y_step = 1.5

    for depth, nodes in enumerate(levels):
        y = -depth * y_step
        n_nodes = len(nodes)
        if n_nodes == 1:
            x_positions = [0]
        else:
            span = min(max_width * 0.8, n_nodes * 1.5)
            x_positions = np.linspace(-span/2, span/2, n_nodes)

        for x, node in zip(x_positions, nodes):
            circle = plt.Circle((x, y), 0.35, color=CP['cyan'], ec=CP['white'], linewidth=2, zorder=3)
            ax.add_patch(circle)
            ax.text(x, y, node, ha='center', va='center', color=CP['white'],
                    fontsize=9, fontweight='bold', zorder=4)

            # Draw connections to next level (simple heuristic)
            if depth < len(levels) - 1:
                next_nodes = levels[depth + 1]
                ratio = len(next_nodes) // max(n_nodes, 1)
                idx_start = sum(len(levels[d]) for d in range(depth + 1)) - len(next_nodes)
                # This is a simplified visualization

    ax.set_xlim(-max_width, max_width)
    ax.set_ylim(-len(levels) * y_step - 1, 1)
    ax.set_aspect('equal')
    ax.axis('off')
    ax.set_title(title, color=CP['bright_cyan'], fontsize=16, fontweight='bold', pad=15)
    plt.tight_layout()
    return fig


def plot_asymptotic_growth(max_n: int = 100):
    """Plot growth of common complexity functions"""
    fig, ax = _setup_cyber_fig((12, 7))
    n = np.linspace(1, max_n, 500)

    functions = [
        ("O(1)", np.ones_like(n), CP['green']),
        ("O(log n)", np.log2(n), CP['cyan']),
        ("O(n)", n, CP['yellow']),
        ("O(n log n)", n * np.log2(n), CP['violet']),
        ("O(n²)", n**2, CP['red']),
    ]

    for label, y, color in functions:
        # Normalize for visibility if needed
        y_plot = np.clip(y, 0, max_n * 2)
        ax.plot(n, y_plot, label=label, color=color, linewidth=2.5)

    ax.set_xlabel("Input Size (n)", color=CP['gray'], fontsize=12)
    ax.set_ylabel("Operations", color=CP['gray'], fontsize=12)
    ax.set_title("Asymptotic Growth Comparison", color=CP['bright_cyan'], fontsize=16, fontweight='bold', pad=15)
    ax.legend(facecolor=CP['panel'], edgecolor=CP['grid'], labelcolor=CP['gray'])
    ax.grid(color=CP['grid'], linestyle='--', alpha=0.5)
    ax.set_ylim(0, max_n * 2)
    plt.tight_layout()
    return fig
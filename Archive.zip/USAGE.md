# USSU Algorithm Analyzer v4.0 - Usage Guide

## Quick Start

### Option 1: Streamlit Web UI (Recommended)
Beautiful cyberpunk web interface with visualizations.

**Linux / Kali / macOS:**
```bash
./install.sh
./start.sh
```

**Windows 11:**
```powershell
install.bat
start.bat
```

Then open **http://localhost:8501**

### Option 2: Terminal CLI
For headless servers or terminal enthusiasts.

**Linux / Kali:**
```bash
./install.sh
./start_cli.sh
```

**Windows:**
```powershell
install.bat
start_cli.bat
```

Or directly:
```bash
python app_cli.py
```

## Navigation

### Streamlit Pages
| Page | Description |
|------|-------------|
| 🏠 Home | Dashboard with feature overview |
| 🕸️ Graph | Interactive graph algorithms with NetworkX viz |
| 🔍 Search | 8 searching algorithms with benchmark comparison |
| 📊 Sort | 13 sorting algorithms with step visualization |
| 🧩 DP | 7 dynamic programming problems with DP table viz |
| 💎 Greedy | 5 greedy algorithms with interactive inputs |
| 🌲 Backtrack | 5 backtracking puzzles (N-Queens, Sudoku, etc.) |
| 📚 ADA | Master theorem, NP theory, amortized analysis |
| 🔢 Math | Number theory, matrix ops, combinatorics |
| ⏱️ Benchmark | Cross-size performance profiling |
| ⚖️ Compare | Head-to-head algorithm battles |

### CLI Menu
```
[1] Graph Algorithms      [6] Backtracking
[2] Searching             [7] Math Tools
[3] Sorting               [8] ADA Theory
[4] Dynamic Programming     [9] Benchmark Suite
[5] Greedy Algorithms      [10] Compare All
[Q] Quit
```

## Keyboard Shortcuts (Streamlit)
- `R` - Rerun page
- `C` - Clear cache
- `?` - Show help

## Troubleshooting

### "streamlit: command not found" (Kali Linux)
The `start.sh` script automatically detects this and uses `python -m streamlit` instead.

### Port already in use
Edit `.streamlit/config.toml` or run with:
```bash
streamlit run app.py --server.port 8502
```

### Missing dependencies
```bash
pip install -r requirements.txt
```

## Author
**Ussu** - [github.com/issu321](https://github.com/issu321)
